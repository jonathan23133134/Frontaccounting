<html>
 <head>
 <meta charset="utf-8">
 <title>Iniciar Sesión</title>
<style> 
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
body{
 background-image:url('img/login.jpg');
 background-size:cover;
}
/*Contenedor*/
.contenedor{
 width:100%;
 height:100%;
 display:flex;
 align-items:center;
 justify-content:center;
}
/*Login*/
.login{
 width:380px;
 height:525px;
 border-radius:25px;
 padding:15px;
 background-color:#d7dbdd;
 box-shadow: 0px 0px 20px black;
 text-align:center;
 border:1px solid blue;
}
/*Titulo y parrafo*/
h1, p{
 color:black;
 font-weight:bold;
}
/*Input.*/
input[type=text],input[type=password]{
 width:50%;
 height:40px;
 text-align:center;
 color:blue;
 border:0;
 border-bottom:2px solid black;
 font-size:100%;
 font-weight:bold;
 background-color:transparent;
}
input:focus{
 outline: none;
}
/*Input submit*/
input[type=submit]{
 width:36%;
 height:40px;
 font-size:100%;
 font-weight:bold;
 text-align:center;
 color:black;
 cursor:pointer;
 background-color: #369681;
 border:1px solid orange;
 border-radius:5%;
}
/*Imagen*/
img{
 filter: drop-shadow(0px 2px 5px white); 
}
a{ text-decoration:none; font-size:140%;}
</style>
</head>
<body>

<div class="contenedor">
<div class="login">
 <form action="#" method="post"><br> 
   <h1>Iniciar Sesión</h1><br>
   <img src="img/logo.png" width="50%"><br><br>
   <p>Usuario:</p><input type="text" name="usuario" placeholder="👤 " required><br><br>
   <p>Contraseña:</p><input type="password" name="contraseña" placeholder="🔒 " required><br><br><br>
   <input type="submit" name="Enviar" value="Ingresar"><a href="index.php">&nbsp; &nbsp; &nbsp; ↩️</a>
  </form>
 </div>
</div>

<?php
include 'conexion.php';

if(isset($_POST['usuario'],$_POST['contraseña'])){
 $usuario=$_POST['usuario'];
 $contraseña=$_POST['contraseña'];
} else {
 $usuario='';
 $contraseña='';
}
//Administrador
if($usuario !== '' && $contraseña !== ''){
 $result=mysqli_query($conexion, "SELECT * FROM usuario_director WHERE usuario = '$usuario' AND contraseña = '$contraseña'");
if($result == true && mysqli_num_rows($result) > 0){
 session_start();
 $_SESSION['usuario']=$usuario;
 header("location: director/administrar.php");
 exit();
 } 
}
//Profesor
if($usuario !== '' && $contraseña !== ''){
 $result=mysqli_query($conexion, "SELECT * FROM usuario_profesor WHERE usuario = '$usuario' AND contraseña = '$contraseña'");
if($result == true && mysqli_num_rows($result) > 0){
 session_start();
 $_SESSION['usuario']=$usuario;
 header("location: profesor/administrar.php");
 exit();
 } 
}
//Estudiante
if($usuario !== '' && $contraseña !== ''){
 $result=mysqli_query($conexion, "SELECT * FROM usuario_estudiante WHERE usuario = '$usuario' AND contraseña = '$contraseña'");
if($result == true && mysqli_num_rows($result) > 0){
 session_start();
 $_SESSION['usuario']=$usuario;
 header("location: estudiante/principal/cursos.php");
 exit();
 } 
}
mysqli_close($conexion);

if(isset($usuario)){
 session_start();
 session_destroy();
}
?>

</body>
</html>

