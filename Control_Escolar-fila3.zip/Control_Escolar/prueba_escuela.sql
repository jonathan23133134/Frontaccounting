-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 11-04-2024 a las 11:27:21
-- Versión del servidor: 8.0.36-0ubuntu0.20.04.1
-- Versión de PHP: 7.4.3-4ubuntu2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `prueba_escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignatura`
--

CREATE TABLE `asignatura` (
  `id_asignatura` int NOT NULL,
  `nombre_asignatura` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `imagen` varchar(75) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `asignatura`
--

INSERT INTO `asignatura` (`id_asignatura`, `nombre_asignatura`, `imagen`) VALUES
(1, 'Lenguaje y Literatura', '../../fotos/lenguaje.jpg'),
(2, 'Matemática', '../../fotos/matematica.jpg'),
(38, 'Ciencias Naturales', '../../fotos/ciencias.jpg'),
(41, 'Estudios Sociales', '../../fotos/sociales.jpg'),
(42, 'Educación Física', '../../fotos/fisica.png'),
(43, 'Moral Urbanidad y Cívica', '../../fotos/moral.jpeg'),
(45, 'Orientación Para la Vida', '../../fotos/opv.jpg'),
(46, 'Sistemas Operativos', '../../fotos/sistemas.png'),
(47, 'Juan la Prueba', ''),
(57, 'modulo', '../../fotos/modulo.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calificacion`
--

CREATE TABLE `calificacion` (
  `id_calificacion` int NOT NULL,
  `id_estudiante` int NOT NULL,
  `id_curso` int NOT NULL,
  `id_asignatura` int NOT NULL,
  `id_profesor` int NOT NULL,
  `id_periodo` int NOT NULL,
  `nota1` int NOT NULL,
  `nota2` int NOT NULL,
  `nota3` int NOT NULL,
  `promedio` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `calificacion`
--

INSERT INTO `calificacion` (`id_calificacion`, `id_estudiante`, `id_curso`, `id_asignatura`, `id_profesor`, `id_periodo`, `nota1`, `nota2`, `nota3`, `promedio`) VALUES
(70, 31, 39, 46, 47, 1, 10, 4, 10, '8'),
(71, 31, 39, 45, 47, 1, 9, 8, 7, '8'),
(72, 67, 43, 45, 72, 1, 8, 8, 8, '8'),
(73, 65, 39, 41, 47, 1, 7, 5, 9, '7'),
(74, 44, 39, 41, 47, 1, 8, 8, 5, '7'),
(75, 44, 39, 41, 47, 2, 5, 6, 6, '6'),
(76, 31, 39, 1, 47, 1, 9, 10, 9, '9');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

CREATE TABLE `curso` (
  `id_curso` int NOT NULL,
  `nombre_curso` varchar(75) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `imagen_curso` varchar(75) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `curso`
--

INSERT INTO `curso` (`id_curso`, `nombre_curso`, `imagen_curso`) VALUES
(39, 'Primer Grado', '../../fotos/pg.jpg'),
(40, 'Segundo Grado', '../../fotos/2g.jpg'),
(41, 'Tercer Grado', '../../fotos/3g.jpg'),
(42, 'Cuarto Grado', '../../fotos/4g.jpg'),
(43, 'Quinto Grado', '../../fotos/5g.jpg'),
(44, 'Sexto Grado', '../../fotos/6g.jpg'),
(45, 'Seṕtimo Grado', '../../fotos/7g.png'),
(46, 'Octavo Grado', '../../fotos/8g.jpg'),
(47, 'Noveno Grado', '../../fotos/9g.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiante`
--

CREATE TABLE `estudiante` (
  `id_estudiante` int NOT NULL,
  `nie` int NOT NULL,
  `nombre` varchar(75) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `apellidos` varchar(75) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `sexo` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `edad` int NOT NULL,
  `id_curso` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `estudiante`
--

INSERT INTO `estudiante` (`id_estudiante`, `nie`, `nombre`, `apellidos`, `sexo`, `edad`, `id_curso`) VALUES
(31, 2459569, 'José ', 'Gómez ', 'M', 19, 47),
(44, 112, 'Dilan', 'Perez', 'M', 1, 39),
(57, 8373, 'Estudiante', 'Prueba', 'M', 18, 40),
(65, 231, 'Fer', 'Black', 'M', 12, 39),
(66, 3231, 'Marco', 'Vasquez', 'M', 1, 45),
(67, 453345, 'Emil', 'Sanabria ', 'M', 20, 43),
(69, 12312312, 'Bryan', 'Guardado', 'M', 18, 47);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `periodo`
--

CREATE TABLE `periodo` (
  `id_periodo` int NOT NULL,
  `nombre_periodo` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `periodo`
--

INSERT INTO `periodo` (`id_periodo`, `nombre_periodo`) VALUES
(1, 'Periodo 1'),
(2, 'Periodo 2'),
(3, 'Periodo 3'),
(4, 'Periodo 4');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `id_profesor` int NOT NULL,
  `nie_profesor` int NOT NULL,
  `nombre_profesor` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `apellidos_profesor` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `genero` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `imagen_profesor` varchar(75) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `id_curso` int NOT NULL,
  `id_asignatura` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`id_profesor`, `nie_profesor`, `nombre_profesor`, `apellidos_profesor`, `genero`, `imagen_profesor`, `id_curso`, `id_asignatura`) VALUES
(47, 25520, 'Gustavo  ', 'García', 'M', '../fotos/profe.png', 47, 46),
(48, 10328, 'Hector ', 'Lavarra', 'M', '../fotos/Presidente_Gustavo_Petro_Urrego.jpg', 40, 1),
(53, 7556, 'Juan', 'Pérez', 'M', '../fotos/juan.png', 39, 1),
(55, 2005, 'Antonio', 'Ruiz', 'M', '../fotos/juan.png', 45, 46),
(72, 2024, 'Lelto', 'Garcia', 'M', '../fotos/juan.png', 43, 45),
(94, 100001, 'mj', 'j', 'M', '../fotos/', 42, 1),
(95, 220000, 'Pepe', 'Mujica', 'M', '../fotos/el pepe.jpeg', 41, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor_responsabilidad`
--

CREATE TABLE `profesor_responsabilidad` (
  `id_profesor` int NOT NULL,
  `id_curso` int NOT NULL,
  `id_asignatura` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `profesor_responsabilidad`
--

INSERT INTO `profesor_responsabilidad` (`id_profesor`, `id_curso`, `id_asignatura`) VALUES
(47, 39, 41),
(47, 47, 46),
(47, 41, 46),
(72, 43, 45),
(55, 45, 46),
(47, 39, 1),
(47, 47, 1),
(48, 40, 1),
(53, 39, 42),
(47, 47, 45),
(55, 47, 2),
(48, 40, 57),
(47, 39, 43),
(94, 42, 1),
(95, 41, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_director`
--

CREATE TABLE `usuario_director` (
  `id_usuario` int NOT NULL,
  `usuario` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `contraseña` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `imagen` varchar(75) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `usuario_director`
--

INSERT INTO `usuario_director` (`id_usuario`, `usuario`, `contraseña`, `imagen`) VALUES
(1, 'admin', 'admin', '../fotos/admin.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_estudiante`
--

CREATE TABLE `usuario_estudiante` (
  `id_usuario` int NOT NULL,
  `id_estudiante` int NOT NULL,
  `usuario` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `contraseña` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `usuario_estudiante`
--

INSERT INTO `usuario_estudiante` (`id_usuario`, `id_estudiante`, `usuario`, `contraseña`) VALUES
(36, 31, 'usuario', '2024'),
(39, 44, 'dilan', '196'),
(44, 57, '8373@edu.sv', '180003'),
(51, 65, 'juan ', '12345'),
(52, 66, '3231@edu.sv', '407553'),
(53, 67, 'estudiante', '2020'),
(55, 69, '12312312@edu.sv', '854509');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_profesor`
--

CREATE TABLE `usuario_profesor` (
  `id_usuario` int NOT NULL,
  `id_profesor` int NOT NULL,
  `usuario` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `contraseña` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `usuario_profesor`
--

INSERT INTO `usuario_profesor` (`id_usuario`, `id_profesor`, `usuario`, `contraseña`) VALUES
(40, 47, 'profesor', 'profesor'),
(41, 48, 'usuario10', '2030'),
(44, 53, 'juanserver', '2050'),
(46, 55, '2005@mined.sv', '3358394'),
(58, 72, '2024@mined.sv', '4150530'),
(88, 94, '100001@mined.sv', '18668'),
(89, 95, '220000@mined.sv', '18607');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asignatura`
--
ALTER TABLE `asignatura`
  ADD PRIMARY KEY (`id_asignatura`);

--
-- Indices de la tabla `calificacion`
--
ALTER TABLE `calificacion`
  ADD PRIMARY KEY (`id_calificacion`),
  ADD KEY `calificacion_estudiante` (`id_estudiante`),
  ADD KEY `calificacion_asignatura` (`id_asignatura`),
  ADD KEY `calificacion_profesor` (`id_profesor`),
  ADD KEY `calificacion_periodo` (`id_periodo`),
  ADD KEY `calificacion_curso` (`id_curso`);

--
-- Indices de la tabla `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id_curso`);

--
-- Indices de la tabla `estudiante`
--
ALTER TABLE `estudiante`
  ADD PRIMARY KEY (`id_estudiante`),
  ADD UNIQUE KEY `nie` (`nie`),
  ADD KEY `estudiante_curso` (`id_curso`);

--
-- Indices de la tabla `periodo`
--
ALTER TABLE `periodo`
  ADD PRIMARY KEY (`id_periodo`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`id_profesor`),
  ADD UNIQUE KEY `nie_profesor` (`nie_profesor`),
  ADD KEY `profesor_asignatura` (`id_asignatura`),
  ADD KEY `profesor_curso` (`id_curso`);

--
-- Indices de la tabla `profesor_responsabilidad`
--
ALTER TABLE `profesor_responsabilidad`
  ADD KEY `responsabilidad_profesor` (`id_profesor`),
  ADD KEY `responsabilidad_curso` (`id_curso`),
  ADD KEY `responsabilidad_asignatura` (`id_asignatura`);

--
-- Indices de la tabla `usuario_director`
--
ALTER TABLE `usuario_director`
  ADD PRIMARY KEY (`id_usuario`);

--
-- Indices de la tabla `usuario_estudiante`
--
ALTER TABLE `usuario_estudiante`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `usuario_estudiante` (`id_estudiante`);

--
-- Indices de la tabla `usuario_profesor`
--
ALTER TABLE `usuario_profesor`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `usuario_profesor` (`id_profesor`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asignatura`
--
ALTER TABLE `asignatura`
  MODIFY `id_asignatura` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT de la tabla `calificacion`
--
ALTER TABLE `calificacion`
  MODIFY `id_calificacion` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT de la tabla `curso`
--
ALTER TABLE `curso`
  MODIFY `id_curso` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT de la tabla `estudiante`
--
ALTER TABLE `estudiante`
  MODIFY `id_estudiante` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT de la tabla `periodo`
--
ALTER TABLE `periodo`
  MODIFY `id_periodo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `profesor`
--
ALTER TABLE `profesor`
  MODIFY `id_profesor` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT de la tabla `usuario_director`
--
ALTER TABLE `usuario_director`
  MODIFY `id_usuario` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuario_estudiante`
--
ALTER TABLE `usuario_estudiante`
  MODIFY `id_usuario` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT de la tabla `usuario_profesor`
--
ALTER TABLE `usuario_profesor`
  MODIFY `id_usuario` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `calificacion`
--
ALTER TABLE `calificacion`
  ADD CONSTRAINT `calificacion_asignatura` FOREIGN KEY (`id_asignatura`) REFERENCES `asignatura` (`id_asignatura`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `calificacion_curso` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id_curso`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `calificacion_estudiante` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiante` (`id_estudiante`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `calificacion_periodo` FOREIGN KEY (`id_periodo`) REFERENCES `periodo` (`id_periodo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `calificacion_profesor` FOREIGN KEY (`id_profesor`) REFERENCES `profesor` (`id_profesor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `estudiante`
--
ALTER TABLE `estudiante`
  ADD CONSTRAINT `estudiante_curso` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id_curso`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD CONSTRAINT `profesor_asignatura` FOREIGN KEY (`id_asignatura`) REFERENCES `asignatura` (`id_asignatura`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `profesor_curso` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id_curso`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `profesor_responsabilidad`
--
ALTER TABLE `profesor_responsabilidad`
  ADD CONSTRAINT `responsabilidad_asignatura` FOREIGN KEY (`id_asignatura`) REFERENCES `asignatura` (`id_asignatura`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `responsabilidad_curso` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id_curso`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `responsabilidad_profesor` FOREIGN KEY (`id_profesor`) REFERENCES `profesor` (`id_profesor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario_estudiante`
--
ALTER TABLE `usuario_estudiante`
  ADD CONSTRAINT `usuario_estudiante` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiante` (`id_estudiante`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario_profesor`
--
ALTER TABLE `usuario_profesor`
  ADD CONSTRAINT `usuario_profesor` FOREIGN KEY (`id_profesor`) REFERENCES `profesor` (`id_profesor`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
