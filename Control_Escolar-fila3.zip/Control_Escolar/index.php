<html>
 <head>
 <meta charset="utf-8">
 <title>Control Escolar: 10160</title>
 </head>
<style>
*{
 margin:0;
 padding:0;
 box-sizing:border-box;
}
/*Contenedor*/
.contenedor{
 width:100%;
 height:100vh;
 display:flex;
 align-items:center;
 justify-content:center;
 background-color:black;
}
/*Login*/
.login{
 width:660px;
 height:450px;
 background-color:#f1f0fa;
 border-radius:3%;
 overflow:hidden;
 font-family:sans-serif;
 font-size:100%;
 font-weight:bold;
 box-shadow: 0px 0px 45px grey;
}
h1{
 font-size:33px;
 margin-top:4%;
}
img{
filter:drop-shadow(0px 0px 10px grey);
}
/*Inputs*/
input[type=submit]{
 margin-left:1%;
 width:25%;
 height:48px;
 background-color:#28b463;
 border-radius:5%;
 color:black;
 font-weight:bold;
 font-size:18px;
 cursor:pointer;
}
/*Efecto hover*/
input:hover{
 transform:scale(1.1);
 background-color:#3498db;
}
</style>
<body>

<div class="contenedor">
 <div class="login">
  <center><br>
   <h1>Control Escolar 10160</h1><br>
   <img src="img/logo.png" width="40%"> 
   <form action="#" method="post"><br>
    <input type="submit" value="Director" name="opcion">
    <input type="submit" value="Profesor" name="opcion">
    <input type="submit" value="Estudiante" name="opcion">
   </form><br><br>
   </center>
 </div> 
</div>

<?php
if($_POST){
 $opcion=$_POST['opcion'];
 
if($opcion != ""){
 header("location:login.php");
 }
}
?>
</body>
</html>







