<html>
<head>
<meta charset="utf-8">
<title>Cursos</title>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
  border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
/*Efecto Hover.*/
.nav tr td a:hover{
 color:yellow;
}
.nav tr td a{
font-size:110%;
text-decoration:none;
color:white;
}
.nav tr td img{
margin-left:5%;
padding:3px 3px;
}
/*Header*/
.cabecera{
 width:90%;
 height:auto;
 background-color:transparent;
 border-radius:2%;
 border:1px solid white;
 overflow:hidden;
 margin:17.5% 5%
}
p{ 
 text-align:center;
 font-size:120%;
}
/*Cursos Disponibles*/
#h2{
 text-align:center;
 color: #397dca ;
 font-weight:bold;
 font-size:270%;
}
/*Div curso*/
.prueba{
 float:left;
 width:325px;
 height: 400px;
 background:#f1f1f1;
 margin:3% 4%;
 overflow:hidden;
 text-align:center;
 border:1px solid  grey;
 border-radius:3%;
}
.prueba:hover{
 box-shadow:7px 13px 20px 5px grey;
 transform:scale(1.1);
 border:2px solid blue;
}
#img{
 width:100%;
 height:45%;
 border-radius:2%;
}
.prueba a{
 font-size:19px;
 background: #ec7063;
 padding:10px;
 font-weight:bold;
 cursor:pointer;
 color: #212f3c ;
 border-radius:3%;
 text-decoration:none;
}
h1{
 text-align: center;
 margin-bottom: 20px;
}
</style>
</head>
<body>

<?php
//Recibir usuario
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="img/newlogo.png" width="20%"></td>
  <td><a href="#"> Inicio</a></td>
  <td><a href="asignaturas.php">Asignaturas</a></td>
  <td><a href="registro.php">Calificaciones</a></td>
  <td><a href="cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<!--Header-->
<div class="cabecera">
 <center><img src="img/cont.png" width="93%"></center>
</div>

<?php 
include 'conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM `estudiante` 
INNER JOIN usuario_estudiante ON estudiante.id_estudiante = usuario_estudiante.id_estudiante 
INNER JOIN curso ON estudiante.id_curso = curso.id_curso 
WHERE usuario_estudiante.usuario = '$usuario'");
$datos=mysqli_fetch_array($result);
$curso_actual=$datos['id_curso'];
?>

<!--Matricularse-->
<?php 
if($_GET){
 $id_curso=$_GET['id'];
 if($id_curso != "" && $id_curso != $curso_actual){
  echo "<script>alert('No posees permiso para automatricularte');</script>";
 } else {
  echo "<script>alert('Ya estas matriculado en el curso.');</script>";
 }
}
?>

<h1 id="h2">💻  Cursos Disponibles</h1>
<?php
include 'conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM curso");
while ($curso=mysqli_fetch_array($result)){ ?>
 <div class="prueba"><br>
  <img src="<?php echo $curso['imagen_curso']; ?>" id="img"><br><br><br>
  <h1><?php echo $curso['nombre_curso']; ?></h1><br>
  <a href="cursos.php?id=<?php echo $curso['id_curso']; ?>">
  <?php if ($curso['id_curso'] == $curso_actual){
  echo "✅ Matriculado";
  } else {
  echo "Matricularse";
  } ?>
  </a>
 </div>
<?php } ?>

</body>
</html>
