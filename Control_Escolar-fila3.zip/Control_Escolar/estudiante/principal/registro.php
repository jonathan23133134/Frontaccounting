<html>
 <head>
 <meta charset="utf-8">
 <title>Registro Calificación</title>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
body{
 background-color:white;
}
 /*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
}
/*Propiedades para efecto hover*/
.nav tr td a:hover{
 color:yellow;
}
.nav tr td a{
 font-size:110%;
 text-decoration:none;
 color:white;
}
.nav td{
 border:0;
 text-align:left;
 padding:0;
}
.nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
/*Tabla de registros*/
.table{
 background-color:white;
 text-align:left;
 width:920px;
 border-collapse:collapse;
 margin:10.5%;
 border:1px solid;
}
.table tr{
 text-align:center;
 border:1px solid black;
}
.table th ,td {
 padding:10px;
 border:1px solid black;
}
.table th{
 background-color:#246355;
 border-bottom:solid 5px #0F362D;
 color:white;
}
.table #cabecera{
width:40%;
padding:8px;
background:grey;
background:#ddd;
border:0;
}
#h1{
 text-align:center;
}
/*Inputs*/
input[type=submit]{
 font-size:100%;
 background-color: #3b95b9;
 padding:3px 10px;
 border-radius:5%;
 cursor:pointer;
}
select{
 font-size:100%;
 text-align:center;
 padding:3px 10px;
 border-radius:3%;
 border:1px solid black;
 margin:1%;
}
</style>
</head>
<body>

<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="img/newlogo.png" width="20%"></td>
  <td><a href="cursos.php"> Inicio</a></td>
  <td><a href="#"> Calificaciones</a></td>
  <td><a href="cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<center>
<table class="table">
 
<tr>
 <td colspan="5" id="cabecera" >
  <h1 id="h1">Notas Registradas</h1>
 </td>
 <td colspan="2" id="cabecera">
  <form action="#" method="post">
  <select name="periodo">
   <option>--</option>
   <?php
   include 'conexion.php';
   $result=mysqli_query($conexion, "SELECT * FROM periodo");
   while($periodos=mysqli_fetch_array($result)){ ?>
    <option value="<?php echo $periodos['id_periodo']; ?>"><?php echo $periodos['nombre_periodo']; ?></option>
   <?php } ?>
  </select>
  <br><input type="submit" value="Filtrar por periodo" name="filtrar">
  </form>
 </td>
</tr>

<tr>
 <th width="14.2%">Nie</th>
 <th width="14.2%">Nombre</th>
 <th width="14.2%">Apellidos</th>
 <th width="14.2%">Sexo</th>
 <th width="14.2%">Edad</th>
 <th width="14.2%">Curso</th>
 <th width="14.2%">Orientador</th>
</tr>

<?php
//Recibir el id_periodo
if($_POST['filtrar']){
 $id_periodo=$_POST['periodo'];
}

include 'conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM estudiante 
INNER JOIN curso ON estudiante.id_curso = curso.id_curso 
INNER JOIN profesor ON profesor.id_curso = curso.id_curso 
INNER JOIN usuario_estudiante ON estudiante.id_estudiante = usuario_estudiante.id_estudiante 
WHERE usuario = '$usuario'");
$datos=mysqli_fetch_array($result);
if(isset($datos)){?>
 <tr>
  <td><?php echo $datos['nie']; ?></td>
  <td><?php echo $datos['nombre']; ?></td>
  <td><?php echo $datos['apellidos']; ?></td>
  <td><?php echo $datos['sexo']; ?></td>
  <td><?php echo $datos['edad']; ?></td>
  <td><?php echo $datos['nombre_curso']; ?></td>
  <td><?php echo $datos['nombre_profesor']."".$datos['apellidos_profesor']; ?></td>
 </tr>
<?php } ?>

<tr>
 <th>Periodo</th>
 <th>Asignatura</th>
 <th>Nota 1</th>
 <th>Nota 2</th>
 <th>Nota 3</th>
 <th>Promedio</th>
 <th>Estado</th>
</tr>

<?php
if(isset($id_periodo)){
 include 'conexion.php';
 $result=mysqli_query($conexion, "SELECT * FROM calificacion 
 INNER JOIN estudiante ON calificacion.id_estudiante = estudiante.id_estudiante 
 INNER JOIN curso c ON calificacion.id_curso = c.id_curso 
 INNER JOIN asignatura a ON calificacion.id_asignatura = a.id_asignatura 
 INNER JOIN profesor p ON calificacion.id_profesor = p.id_profesor 
 INNER JOIN periodo ON calificacion.id_periodo = periodo.id_periodo 
 INNER JOIN usuario_estudiante ue ON calificacion.id_estudiante = ue.id_estudiante 
 WHERE usuario ='$usuario' AND calificacion.id_periodo = '$id_periodo'");
 if(mysqli_num_rows($result) == 0){
  echo "<tr><td colspan='7'><font color='blue'>No hay notas registradas</font></td></tr>"; 
 } else {
 while ($mostrar=mysqli_fetch_array($result)){ ?>
  <tr>
   <td><?php echo $mostrar['nombre_periodo']; ?></td>
   <td><?php echo $mostrar['nombre_asignatura']; ?></td>
   <td><?php echo $mostrar['nota1']; ?></td>
   <td><?php echo $mostrar['nota2']; ?></td>
   <td><?php echo $mostrar['nota3']; ?></td>
   <td><?php echo $mostrar['promedio']; ?></td>
   <td>
   <?php 
   if($mostrar['promedio'] < 7 ){ 
    echo "<font color='red'>❌ Reprobado</font>"; }else{
    echo "<font color='green'>✅ Aprobado</font>"; } ?>
   </td>
 </tr>
<?php  } } }?>

</table>
</center>
</div>

</body>
</htlm>
