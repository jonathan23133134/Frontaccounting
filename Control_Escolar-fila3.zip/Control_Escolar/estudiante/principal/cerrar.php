<?php
//Se recupera y se continua la sesión enviada. Se destruye la sesión y se redirecciona a la página de inicio.
 session_start();
 session_destroy();
 header("location:../../index.php");
 exit();
?>
