<?php
//Conexión al servidor y base de datos
$conexion = mysqli_connect('localhost', 'jose', 'jose200516', 'prueba_escuela');

// Desactivar toda notificación de error
error_reporting(0);
?>
