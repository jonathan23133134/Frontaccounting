<html>
<head>
<meta charset="utf-8">
<title>Asignaturas</title>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu', sans-serif;
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
  border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
/*Efecto hover*/
.nav tr td a:hover{
 color:yellow;
}
.nav tr td a{
font-size:110%;
text-decoration:none;
color:white;
}
.nav tr td img{
margin-left:5%;
padding:3px 3px;
}
/*Header*/
.cabecera{
 width:90%;
 height:auto;
 background-color:transparent;
 /*box-shadow:5px 6px 10px grey;*/
 border-radius:2%;
 border:1px solid white;
 overflow:hidden;
 margin:17.5% 5%
}
#h2{
 text-align:center;
 color: #397dca ;
 font-weight:bold;
 font-size:270%;
}
/*Div asignatura*/
.prueba{
 float:left;
 width:325px;
 height: 400px;
 background:#f1f1f1;
 margin:3% 4%;
 overflow:hidden;
 text-align:center;
 border:1px solid  grey;
 border-radius:3%;
}
.prueba:hover{
 box-shadow:7px 13px 20px 5px grey;
 transform:scale(1.1);
 border:2px solid red;
}
#img{
 width:100%;
 height:45%;
 border-radius:2%;
}
.prueba a{
 font-size:18px;
 background-color:#246355;
 padding:10px;
 font-weight:bold;
 cursor:pointer;
 color: white;
 border-radius:5%;
 text-decoration:none;
}
h1{
 text-align: center;
 margin-bottom: 20px;
}
</style>
</head>
<body>

<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="img/newlogo.png" width="20%"></td>
  <td><a href="cursos.php"> Inicio</a></td>
  <td><a href="cursos.php">Asignaturas</a></td>
  <td><a href="registro.php">Calificaciones</a></td>
  <td><a href="../../index.php">🔒 Salir</a></td>
 </tr>
</table>

<!--Header-->
<div class="cabecera">
 <center><img src="img/cont.png" width="93%"></center>
</div>

<h1 id="h2">📚 Asignaturas Impartidas</h1>
<?php
//Div asignatura
include 'conexion.php';
$result_asig=mysqli_query($conexion, "SELECT * FROM estudiante INNER JOIN usuario_estudiante ON estudiante.id_estudiante = usuario_estudiante.id_estudiante WHERE usuario = '$usuario' ");
$datos=mysqli_fetch_array($result_asig);
$id_curso=$datos['id_curso'];

 $result=mysqli_query($conexion, "SELECT * FROM `profesor_responsabilidad` 
INNER JOIN estudiante ON profesor_responsabilidad.id_curso = estudiante.id_curso 
INNER JOIN usuario_estudiante ON estudiante.id_estudiante = usuario_estudiante.id_estudiante 
INNER JOIN asignatura ON profesor_responsabilidad.id_asignatura = asignatura.id_asignatura
WHERE profesor_responsabilidad.id_curso = '$id_curso' AND usuario = '$usuario'");
 while ($asignaturas=mysqli_fetch_array($result)){ ?>
  <div class="prueba"><br>
   <img src="<?php echo $asignaturas['imagen']; ?>" id="img"><br><br><br>
   <h1><?php echo $asignaturas['nombre_asignatura']; ?></h1><br>
   <a href="asignaturas.php?id=<?php echo $asignaturas['id_asignatura']; ?>">Ver Detalles</a>
  </div>
<?php } ?>

<?php 
if($_GET){
 $asignatura=$_GET['id'];
 if($asignatura != ""){
 echo "<script>alert('No posees permiso para módificar 😂');</script>";
 }
}
?>

</body>
</html>
