<html>
 <head>
 <meta charset="utf-8">
 <title>Administrar Grados</title>
 </head>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
body{
 background-color:#f1f0fa;
}
/*Tabla nav.*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
 .nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 padding:0;
 text-align:left;
 border:0;
}
.nav tr td a{
 font-size:115%;
 text-decoration:none;
 color:white;
}
.nav tr td a:hover{
 color:yellow;
}

/*Tabla de registros*/
.table{
 background-color:white;
 text-align:left;
 width:920px;
 border-collapse:collapse;
 margin:10.5%;
 font-size:115%;
 box-shadow:0px 0px 20px black;
}
.table tr{
 text-align:center;
}
.table th ,td {
 padding:20px;
}
.table th{
 background-color:#246355;
 border-bottom:solid 5px #0F362D;
 color:white;
}
.table tr:nth-child(even){
 background-color:#ddd;
} 
/*Enlaces*/
.editar{
 background:#e74c3c;
 border-radius:5%;
 text-decoration:none;
 padding:5px;
 color:white;
}
</style>
<body>
 
<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="#registro">Registro</a></td>
  <td><a href="agregar_curso.php">Agregar</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<!--Tabla de Registro-->
<center>
<table class="table">
 <tr>
  <th colspan="5">
   <h1 align="center">Registro de Grados</h1>
   <img src="../img/logo.png" width="12%">
  </th>
 </tr>
 
<!--Cabeceras de tablas-->
<tr>
 <th width="10%">Id</th>
 <th width="30%">Nombre</th>
 <th width="30%">Imagén</th>
 <th colspan="2" width="30%">Acción</th>
</tr>
 
<?php
include '../conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM curso");
 while ($cursos=mysqli_fetch_array($result)){ ?>
  <tr>
   <td><?php echo $cursos['id_curso']; ?></td>
   <td><?php echo $cursos['nombre_curso']; ?></td>
   <td><img src="<?php echo $cursos['imagen_curso']; ?>" width="25%"></td>
   <td><a class="editar" href="editar_curso.php?id_curso=<?php echo $cursos['id_curso']; ?>">✏️ Editar</a></td>
   <td><a class="editar" href="grados.php?id_curso=<?php echo $cursos['id_curso']; ?>">⛔️ Eliminar</a></td><!--Enlaces-->
  </tr>
<?php } ?>
</table>
</center>

<?php
//Eliminar
if($_GET['id_curso']){
 $id_curso=$_GET['id_curso'];
 echo "<script>alert('¿Está seguro de eliminar el registro?');</script>";
 include '../conexion.php';
 $result=mysqli_query($conexion, "DELETE FROM curso WHERE curso.id_curso = '$id_curso'");
}
?>
</body>
</html>
