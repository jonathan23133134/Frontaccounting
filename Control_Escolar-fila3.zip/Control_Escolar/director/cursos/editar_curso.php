<html>
 <head>
 <meta charset="utf-8">
 <title>Editar Curso</title>
 </head>
<style>
*{
 margin:0;
 padding:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
/*Div contenedor*/
.contenedor{
 width:100%;
 height:100vh;
 display:flex;
 align-items:center;
 justify-content:center;
 background-color:#f1f0fa;
}
/*Tabla nav.*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
 .nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 padding:0;
 text-align:left;
}
.nav tr td a{
 font-size:115%;
 color: white;
 text-decoration:none;
}
.nav tr td a:hover{
 color:yellow;
}
/*Div formulario*/
.formulario{
 width: 755px;
 height: 380px;
 background-color: #CCD1D1;
 border-radius:1%;
 box-shadow:0px 0px 20px black;
 overflow:hidden;
 margin-top:8%;
}
#section1{
 float:left;
 width:40%;
 height:100%;
 background-color:white;
 text-align:center;
 border-right:8px solid grey;
}
#section1 img{
margin-top:35%;
}
select[name=mantener]{ 
 width:15%;
 height:5%;
 font-size:100%;
}
#section2{
 background-color:white;
 width:100%;
 height:100%;
}
h1{
 font-size:250%;
 margin-top:3%;
 text-align:center;
 color: #324eb6 ;
}
p{
 font-size:120%;
 margin-left:48%;
}
label { font-size:110%; }
/*Inputs*/
input[type=text]{
 margin-left:8%;
 width:40%;
 height:10%;
 font-size:100%;
}
input[type=file]{
 margin-left:8%;
 width:40%;
 height:10%;
 font-size:100%;
}
input[type=submit]{
 width:20%;
 height:12%;
 background-color: #369681;
 font-weight:bold;
 font-size:110%;
 cursor:pointer;
}
</style>
<body>

<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<?php
//Id_curso 
$id_curso=$_GET['id_curso'];
if($id_curso != ""){
 include '../conexion.php';
 $result=mysqli_query($conexion, "SELECT * FROM curso WHERE id_curso = '$id_curso'");
 $datos=mysqli_fetch_array($result);
}
?>

<div class="contenedor">
<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="grados.php">Registro</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<div class="formulario">
 <section id="section1">
  <img src="<?php echo $datos['imagen_curso']; ?>" width="75%" alt="No hay imagen disponible">
  <form action="#" method="post" enctype="multipart/form-data"><br>
   <label>Mantener imagen: </label><br>
   <select name="mantener">
    <option value="si">Si</option>
    <option value="no">No</option>
   </select>
 </section>
  
 <section id="section2"><br><br>
   <h1>Editar Curso</h1><br>
   <p>Nombre: </p>
   <input type="text" name="nombre" value="<?php echo $datos['nombre_curso'];?>" required><br><br>
   <p>Imagen: </p>
   <input type="file" name="foto"><br>
   <br>
   <center><input type="submit" value="Actualizar" name="actualizar"></center>
  </form>
 </section>
</div>
</div>

<?php 
//Img actual
include '../conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM curso WHERE id_curso = '$id_curso'");
$imagen_actual=mysqli_fetch_array($result);
$img_ac=$imagen_actual['imagen_curso'];

//Guardar img actual
if($_POST['actualizar']){
 $mantener=$_POST['mantener'];
 if($mantener == "si"){
  $imagen=$img_ac;
 } else {
  $imagen="";
 }
}

if(isset($_POST['actualizar'])){ 
 $nombre=$_POST['nombre'];

if(isset($_FILES['foto'])){
 $file=$_FILES['foto'];
 $nombre_file=$file['name'];
 $tipo=$file['type'];
 $ruta_provisional=$file['tmp_name']; 
 $carpeta="../../fotos/";
 
if ($tipo != 'image/jpg' && $tipo != 'image/jpeg' && $tipo != 'image/png' && $tipo != 'image/gif'){
 echo "<script>alert('Error, el archivo no es una imagen.');</script>";
 } else{
  $src=$carpeta.$nombre_file;
  move_uploaded_file($ruta_provisional, $src); 
  $imagen="../../fotos/".$nombre_file; 
  }
 }
}

if($nombre != ""){
 //Actualizar
 include '../conexion.php';
 $result_act=mysqli_query($conexion, "UPDATE `curso` SET `nombre_curso` = '$nombre', `imagen_curso` = '$imagen' WHERE `curso`.`id_curso` = '$id_curso'; ");
 mysqli_close($conexion);
}

if($result_act == true){
 header("location: grados.php");
}
?>

</body>
</html>
