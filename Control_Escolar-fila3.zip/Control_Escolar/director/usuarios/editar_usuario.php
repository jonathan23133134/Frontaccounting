<html>
 <head>
 <meta charset="utf-8">
 <title>Usuario Director</title>
 </head>
<style>
*{
 margin:0;
 padding:0;
 box-sizing:border-box;
 font-family:'ubuntu';
 color:white;
}
/*Tabla Nav.*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
 .nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 padding:0;
 text-align:left;
}
.nav tr td a{
 font-size:110%;
 text-decoration:none;
}
.nav tr td a:hover{
 color:yellow;
}

/*Div contenedor*/
.contenedor{
 width:100%;
 height:100%;
 display:flex;
 align-items:center;
 justify-content:center;
 background-color:#f1f0fa;
}
/*Div formulario*/
.form{
 width:450px;
 height:520px;
 background-color: #1c1c1c;
 box-shadow:0px 0px 10px yellow;
 border-radius:3%;
 overflow:hidden;
 margin-top:10.5%;
}
/*Pararfos*/
p{
 font-size:125%;
 margin-left:20%;
}
/*Inputs*/
input[type=text]{
 width:60%;
 height:7%;
 margin-left:20%;
 color:black;
 font-size:110%;
}
input[type=file]{
 width:60%;
 height:9%;
 margin-left:20%;
 color:black;
 font-size:100%;
}
input[type=submit]{
 width:30%;
 height:9%;
 color:black;
 font-size:100%;
 background-color: #28b463;
 cursor:pointer;
}
</style>
<body>

<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="editar_usuario.php">Mi usuario</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>


<?php
include '../conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM usuario_director WHERE usuario = '$usuario'");
$datos=mysqli_fetch_array($result);
$id_usuario=$datos['id_usuario']; 
?>

<div class="contenedor">
 <div class="form">
  <form action="#" method="post" enctype="multipart/form-data">
   <center><br><h1>Datos Personales</h1><br>
   <img src="<?php echo $datos['imagen']; ?>" width="25%" alt="No hay imagen disponible"></center><br>
   <p>Usuario: </p>    <input type="text" name="usuario" value="<?php echo $datos['usuario'] ;?>"><br><br>
   <p>Contraseña: </p> <input type="text" name="contraseña" value="<?php echo $datos['contraseña'] ;?>"><br><br>
   <p>Imagen: </p><input type="file" name="foto"><br><br>
   <center><input type="submit" value="Actualizar" name="Actualizar"></center>
  </form>
 </div>
</div>

<?php
if(isset($_POST['Actualizar'])){ 
 $usuario_director=$_POST['usuario'];
 $contraseña=$_POST['contraseña'];
 
if(isset($_FILES['foto'])){
 $file=$_FILES['foto'];
 $nombre_file=$file['name'];
 $tipo=$file['type'];
 $ruta_provisional=$file['tmp_name']; 
 $carpeta="../fotos/"; 
 
 if ($tipo != 'image/jpg' && $tipo != 'image/jpeg' && $tipo != 'image/png' && $tipo != 'image/gif'){
  echo "<script>alert('Error, el archivo no es una imagen.');</script>";
 } else{
  $src=$carpeta.$nombre_file;
  move_uploaded_file($ruta_provisional, $src);
  $imagen="../fotos/".$nombre_file; 
  }
 }
}

if($usuario_director != "" && $contraseña != ""){
 include '../conexion.php';
 $result=mysqli_query($conexion, "UPDATE `usuario_director` SET `usuario` = '$usuario_director', `contraseña` = '$contraseña', `imagen` = '$imagen' WHERE `usuario_director`.`id_usuario` = '$id_usuario'");
 
 if($result == true){
  header("location: ../cerrar.php");
 }
}
?>

</body>
</html>
