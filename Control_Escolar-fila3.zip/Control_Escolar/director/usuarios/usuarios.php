<html>
 <head>
 <meta charset="utf-8">
 <title>Usuarios</title>
</head>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
body{
 background-color:#f1f0fa;
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
 .nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 border:0;
 padding:0;
 text-align:left;
}
.nav tr td a{
 font-size:115%;
 text-decoration:none;
 padding:5px;
 color:white;
}

.nav tr td a:hover{
 color:yellow;
}

/*Tablas de registro*/
.table{
 background-color:white;
 text-align:left;
 width:850px;
 border-collapse:collapse;
 margin:10.5%;
 font-size:115%;
 border:1px solid black;
 box-shadow:0px 0px 20px black;
}
.table tr{
 text-align:center;
  border:1px solid black;
}
.table th ,td {
 padding:20px;
  border:1px solid black;
}
.table th{
 background-color:#246355;
 border-bottom:solid 5px #0F362D;
 color:white;
}
.table tr:nth-child(even){
 background-color:#ddd;
} 
.table tr:hover {
 background-color:lightblue;
}
/*Enlaces*/
.editar{
 background:#e74c3c;
 border-radius:5%;
 text-decoration:none;
 padding:5px 10px;
 color:white;
}
</style>
<body>
 
<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="#estudiante">Estudiante</a></td>
  <td><a href="editar_usuario.php">Mi usuario</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<!--Usuarios profes-->
<center>
<table class="table">
<tr>
 <th colspan="5">👨‍🏫 Profesores</th>
</tr>
 
<tr>
 <th>Id_usuario</th>
 <th>Profesor</th>
 <th>Usuario</th>
 <th>Contraseña</th>
 <th>Acción</th>
</tr>

<?php
include '../conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM usuario_profesor up INNER JOIN profesor p ON up.id_profesor = p.id_profesor");
while ($usuario_profesor=mysqli_fetch_array($result)){ ?>
 <tr>
  <td><?php echo $usuario_profesor['id_usuario']; ?></td>
  <td><?php echo $usuario_profesor['nombre_profesor']." ".$usuario_profesor['apellidos_profesor']; ?></td>
  <td><?php echo $usuario_profesor['usuario']; ?></td>
  <td><?php echo $usuario_profesor['contraseña']; ?></td>
  <td><a class="editar" href="usuarios.php?id_profesor=<?php echo $usuario_profesor['id_usuario']; ?>">✏️ Editar</a></td>
 </tr>
<?php } ?>
</table>

<!--Usuarios de estudiantes-->
<p id="estudiante"></p>
<table class="table">
<tr>
 <th colspan="5">👨‍🎓 Estudiantes</th>
</tr>
 
<tr>
 <th>Id_usuario</th>
 <th>Estudiante</th>
 <th>Usuario</th>
 <th>Contraseña</th>
 <th>Acción</th>
 </tr>
 
<?php
include '../conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM usuario_estudiante ue INNER JOIN estudiante e ON ue.id_estudiante = e.id_estudiante");
while ($usuario_estudiante=mysqli_fetch_array($result)){ ?>
 <tr>
  <td><?php echo $usuario_estudiante['id_usuario']; ?></td>
  <td><?php echo $usuario_estudiante['nombre']." ".$usuario_profesor['apellidos']; ?></td>
  <td><?php echo $usuario_estudiante['usuario']; ?></td>
  <td><?php echo $usuario_estudiante['contraseña']; ?></td>
  <td><a class="editar" href="usuarios.php?id_estudiante=<?php echo $usuario_estudiante['id_usuario']; ?>">✏️ Editar</a></td>
 </tr>
<?php } ?>
</table>
</center>

<?php
//Editar usuario_profesor
if($_GET['id_profesor']){
 $id_profesor=$_GET['id_profesor'];
 echo "<style>body{overflow-y:hidden ;}</style>";
 
if(isset($id_profesor)){
 $result=mysqli_query($conexion, "SELECT * FROM usuario_profesor WHERE id_usuario = '$id_profesor'");
 
if(mysqli_num_rows($result) != 0){ 
 $datos=mysqli_fetch_array($result);
 $id_usuario_profesor=$datos['id_usuario'];?>
  <div class="contenedor">
   <div class="login">
    <form action="#" method="post">
    <h1>Editar datos</h1><br><center>
    <label>Usuario:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="text" name="usuario" value="<?php echo $datos['usuario']; ?>"><br><br><br>
    <label>Contraseña:</label>&nbsp;&nbsp;
    <input type="text" name="contraseña" value="<?php echo $datos['contraseña']; ?>"><br><br><center>
    <input type="submit" value="Actualizar" name="actualizar">&nbsp;&nbsp;<a href="usuarios.php">Atras</a>
   </form></center>
  </div>
 </div><?php 
  }
 }
}
?>

<?php
if(isset($_POST['actualizar'])){
 $usuario_profesor=$_POST['usuario'];
 $contraseña_profesor=$_POST['contraseña'];
 echo "<style>body{overflow-y:auto ;}</style>";

 include '../conexion.php';
 $result=mysqli_query($conexion, "UPDATE `usuario_profesor` SET `usuario` = '$usuario_profesor', `contraseña` = '$contraseña_profesor' WHERE `usuario_profesor`.`id_usuario` = '$id_usuario_profesor'"); ?>
<style>.contenedor{ visibility:hidden; }</style>
<?php } ?>

<?php
//Editar usuario_estudiante
if($_GET['id_estudiante']){
 $id_estudiante=$_GET['id_estudiante'];
 echo "<style>body{overflow-y:hidden ;}</style>";
 
if(isset($id_estudiante)){
 $result=mysqli_query($conexion, "SELECT * FROM usuario_estudiante WHERE id_usuario = '$id_estudiante'");
  
if(mysqli_num_rows($result) != 0){ 
 $datos=mysqli_fetch_array($result);
 $id_usuario_estudiante=$datos['id_usuario'];?>
 <style>body{ overflow-x:hidden; }</style>
 <div class="contenedor">
  <div class="login">
   <form action="#" method="post">
    <h1>Editar datos</h1><br><center>
    <label>Usuario:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="text" name="usuario" value="<?php echo $datos['usuario']; ?>"><br><br><br>
    <label>Contraseña:</label>&nbsp;&nbsp;
    <input type="text" name="contraseña" value="<?php echo $datos['contraseña']; ?>"><br><br>
    <input type="submit" value="Actualizar" name="actualizar">&nbsp;&nbsp;<a href="usuarios.php">Atras</a>
    </form></center>
   </div>
  </div><?php 
  }
 }
}
?>

<?php
if(isset($_POST['actualizar'])){
 $usuario_estudiante=$_POST['usuario'];
 $contraseña_estudiante=$_POST['contraseña'];
  echo "<style>body{overflow-y:auto ;}</style>";
  
 include '../conexion.php';
 $result=mysqli_query($conexion, "UPDATE `usuario_estudiante` SET `usuario` = '$usuario_estudiante', `contraseña` = '$contraseña_estudiante' WHERE `usuario_estudiante`.`id_usuario` = '$id_usuario_estudiante'"); ?>
 <style> .contenedor{ visibility:hidden; }</style>
 <?php } ?>

</body>
</html>

<style>
.contenedor{
 background:rgba(0,0,0,0.5);
 position:absolute;
 left:0; top:0;
 width:100%;
 height:100%;
 display:flex;
 align-items:center;
 justify-content:center;
}
.login{
 width:550px;
 height:300px;
 background:#ddd;
 box-shadow:0px 0px 20px black;
 }
 .login a{text-decoration:none;
}
h1{
 margin-top:5%;
 text-align:center;
}
label{
 font-size:110%;
}
input{
 text-align:center;
 font-size:110%;
 width:50%;
 height:13%;
}
input[type="submit"]{
 text-align:center;
 font-size:110%;
 width:20%;
 height:13%;
 background:#e74c3c;
cursor:pointer;
}
</style>
