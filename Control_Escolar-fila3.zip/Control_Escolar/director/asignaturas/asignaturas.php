<html>
 <head>
 <meta charset="utf-8">
 <title>Administrar Asignaturas</title>
 </head>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
body{
 background-color:#f1f0fa;
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
.nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 border:0;
 padding:0;
 text-align:left;
}
.nav tr td a{
 font-size:115%;
 color: white;
 text-decoration:none;
}
.nav tr td a:hover{
 color:yellow;
}
/*Tabla de registro*/
.table{
 background-color:white;
 text-align:left;
 width:950px;
 border-collapse:collapse;
 margin-top:10.5%;
 margin-bottom:5%;
 font-size:115%;
 box-shadow:0px 0px 20px black;
}
.table tr{
 text-align:center;
}
.table th ,td {
 padding:20px;
}
.table th{
 background-color:#246355;
 border-bottom:solid 5px #0F362D;
 color:white;
}
.table tr:nth-child(even){
 background-color:#ddd;
} 
.table tr:hover{
background-color:lightblue;
}
/*Enlaces*/
.editar{
 width:100%;
 border: none;
 color:white;
 padding:5px;
 text-decoration:none;
 cursor:pointer;
 background:#e74c3c;
 border-radius:10%;
}
</style>
<body>

<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="#registro">Registro</a></td>
  <td><a href="agregar_asignatura.php">Agregar</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<!--Tabla de Registro-->
<center>
<table class="table">
<tr>
 <th colspan="5">
  <h1 align="center">Registro de Asignaturas</h1>
  <img src="../img/logo.png" width="15%">
 </th>
</tr>
 
<tr>
 <th width="10%">Id</th>
 <th width="30%">Nombre</th>
 <th width="30%">Imágen</th>
 <th colspan="2" width="30%">Acción</th>
</tr>

<?php
 include '../conexion.php';
 $result=mysqli_query($conexion, "SELECT * FROM asignatura");
 while ($asignaturas=mysqli_fetch_array($result)){ ?>
  <tr>
   <td><?php echo $asignaturas['id_asignatura']; ?></td>
   <td><?php echo $asignaturas['nombre_asignatura']; ?></td>
   <td><img src="<?php echo $asignaturas['imagen']; ?>" width="30%"></td>
   <td><a class="editar" href="editar_asignatura.php?id_asignatura=<?php echo $asignaturas['id_asignatura']; ?>">✏️ Editar</a></td>
   <td><a class="editar" href="asignaturas.php?id_asignatura=<?php echo $asignaturas['id_asignatura']; ?>">⛔️ Eliminar</a></td>
  </tr>
 <?php } ?>
 </table>
</center>

<?php
//Eliminar
if($_GET['id_asignatura']){
 $id_asignatura=$_GET['id_asignatura'];
 echo "<script>alert('¿Realmente desea eliminar el registro?');</script>";
 include '../conexion.php';
 $result=mysqli_query($conexion, "DELETE FROM asignatura WHERE asignatura.id_asignatura = '$id_asignatura'");
}
?>

</body>
</html>
