<html>
<head>
<meta charset="utf-8">
<title>Asignar responsabilidades</title>
</head>
<style>
*{
 margin:0;
 padding:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
/*Div contenedor*/
.contenedor{
 width:100%;
 height:100vh;
 
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
/*Efecto hover*/
.nav tr td a:hover{
 color:yellow;
}
.nav tr td a{
 font-size:115%;
}
.nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 padding:0;
 text-align:left;
}
a{
 color: white;
 text-decoration:none;
}

/*Div formulario*/
.formulario{
 width: 900px;
 height: 450px;
 background-color: #CCD1D1;
 border-radius:1%;
 box-shadow:0px 0px 20px black;
 overflow:hidden;
 margin-top:10%;
}
/*Tabla form*/
.form{
 width:100%;
 height:100%;
 background:white;
 border-collapse:collapse;
 overflow:hidden;
}
/*Titulo y parrafos*/
h1{
 font-size:225%;
 text-align:center;
 color: #324eb6 ;
}
p{
 font-size:110%;
 margin-left:7%;
}
label{ font-size:110%; }
/*Inputs*/
input[type=text],select{
 margin-left:7%;
 width:80%;
 height:35%;
 font-size:110%; 
}
input[type=submit]{ 
 width:20%;
 height:100%;
 background-color: #369681;
 font-weight:bold;
 font-size:110%;
 padding:8px;
 cursor:pointer;
}
/*Tabla de registros de responsabilidades*/
.responsabilidades{
 width:600px;
 border-collapse:collapse;
 box-shadow:0px 0px 20px black;
}
.responsabilidades th{
color:white;
 padding:10px;
 background-color:#246355;
 border-bottom:solid 2px #0F362D;
 font-size:115%;
 border:1px solid black;
}
.responsabilidades td{
 padding:10px;
 text-align:center;
 border:1px solid black;
 font-size:115%;
}
</style>
<body>

<?php
//Recibir usuario
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<?php
//Recuperamos el id_profesor enviado por $_GET al presionar el enlace y seleccionamos todos los datos
$id_profesor=$_GET['id_profesor'];
include '../conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM profesor WHERE id_profesor = '$id_profesor'");
$datos=mysqli_fetch_array($result);
$id_profesor=$datos['id_profesor'];
?>

<div class="contenedor">
<!--Tabla Nav-->
<center>
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="profesores.php">Registro</a></td>
  <td><a href="responsabilidades.php?id_profesor=<?php echo $id_profesor;?>">Actualizar</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<div class="formulario">
 <table class="form">
 
<tr>
 <td rowspan="4" width="30%">
 <center><img src="<?php echo $datos['imagen_profesor']; ?>" width="85%" alt="No hay imagen disponible."></td>
 <!--Formulario Para Editar datos del Profesor-->
 <form action="#" method="post" enctype="multipart/form-data">
 <td colspan="2"><h1>Asignar Grados y asignaturas</h1></td>
</tr>
  
<tr>
 <td width="35%">
  <p>Profesor:</p>
  <select name="profesor">
   <option value="<?php echo $id_profesor; ?>"><?php echo $datos['nombre_profesor']." ".$datos['apellidos_profesor']; ?></option>
  </select>
 </td>
</tr>

<tr>
 <td>
  <p>Curso:</p>
  <select name="curso" required>
   <?php 
   include '../conexion.php';
   $result=mysqli_query($conexion, "SELECT * FROM curso");
   while ($cursos=mysqli_fetch_array($result)){?>
    <option value="<?php echo $cursos['id_curso'];?>"><?php echo $cursos['nombre_curso'];?></option>
   <?php } ?>
  </select>
 </td>
 <td> 
  <p>Asignatura:</p>
  <select name="asignatura" required>
   <?php 
   include '../conexion.php';
   $result=mysqli_query($conexion, "SELECT * FROM asignatura");
   while ($asignaturas=mysqli_fetch_array($result)){?>
    <option value="<?php echo $asignaturas['id_asignatura'];?>"><?php echo $asignaturas['nombre_asignatura'];?></option>
   <?php } ?>
  </select>
 </td>
</tr>

<tr>
  <td colspan="2">
   <center>
    <input type="submit" value="Asignar" name="asignar">
    <a href="#responsabilidades"><font color="black">&nbsp;&nbsp;&nbsp;&nbsp;Ver más</font></a>
   </center>
  </td>
</tr>

 </table>
 </center>
</div>
 
<center>
<!--Tabla responsabilidades-->
<p id="responsabilidades"></p>
<table class="responsabilidades">
<tr>
 <th>Curso</th>
 <th>Asignaturas</th>
 <!--<th>Acción</th>-->
</tr>

<?php
 include '../conexion.php';
 $result=mysqli_query($conexion, "SELECT * FROM profesor_responsabilidad 
 INNER JOIN profesor ON profesor_responsabilidad.id_profesor = profesor.id_profesor 
 INNER JOIN curso ON profesor_responsabilidad.id_curso = curso.id_curso 
 INNER JOIN asignatura ON profesor_responsabilidad.id_asignatura = asignatura.id_asignatura  
 WHERE profesor_responsabilidad.id_profesor = '$id_profesor'");
 while($responsabilidades=mysqli_fetch_array($result)){ ?>
  <tr>
   <td><?php echo $responsabilidades['nombre_curso']; ?></td>
   <td><?php echo $responsabilidades['nombre_asignatura']; ?></td>
  </tr>
 <?php } ?>

  </table>
 </center>
</div>
<br>
<br>

<?php
//Recibir datos 
if(isset($_POST['asignar'])){
 $id_profesor=$_POST['profesor'];
 $id_curso=$_POST['curso'];
 $id_asignatura=$_POST['asignatura'];
 
include '../conexion.php';
 $result_verificar1=mysqli_query($conexion, "SELECT * FROM profesor_responsabilidad WHERE id_profesor = '$id_profesor' AND id_curso = '$id_curso' AND id_asignatura = '$id_asignatura'");
 
 $result_verificar2=mysqli_query($conexion, "SELECT * FROM profesor_responsabilidad WHERE id_curso = '$id_curso' AND id_asignatura = '$id_asignatura'");
}

if($id_curso != "" && mysqli_num_rows($result_verificar1) != 0 or $id_curso != "" && mysqli_num_rows($result_verificar2) != 0){
 echo "<script>alert('Los datos seleccionados ya están registrados para este u otro docente.');</script>";
 } else {
 //Si los datos no existen en la tabla los insertamos.
 include '../conexion.php';
 $result=mysqli_query($conexion, "INSERT INTO profesor_responsabilidad (id_profesor, id_curso, id_asignatura) VALUES ('$id_profesor','$id_curso','$id_asignatura')");
}
?>

</body>
</html> 
