<html>
 <head>
 <meta charset="utf-8">
 <title>Agregar Profesor</title>
<style>
*{
 margin:0;
 padding:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
/*Div contenedor*/
.contenedor{
 width:100%;
 height:100vh;
 display:flex;
 align-items:center;
 justify-content:center;
 background-color:#f1f0fa;
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
 .nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 padding:0;
 text-align:left;
}
.nav tr td a{
 font-size:115%;
 color: white;
 text-decoration:none;
}
.nav tr td a:hover{
 color:yellow;
}
/*Div formulario*/
.formulario{
 width: 770px;
 height: 450px;
 border-radius:1%;
 box-shadow:0px 0px 20px  #3498db;
 overflow:hidden;
 margin-top:8%;
}
/*Tabla form*/
.form{
width:100%;
height:100%;
background:white;
border-collapse:collapse;
}
.form td{
width:50%;
}
/*Titulo y parrafos*/
h1{
 font-size:225%;
 text-align:center;
 color: #324eb6 ;
}
p{
 font-size:115%;
 margin-left:17%;
}
/*Inputs*/
input[type=text],input[type=number],select,input[type=file]{
 margin-left:17%;
 width:65%;
 height:40%;
 font-size:100%;
}
input[type=submit]{
 width:20%;
 height:100%;
 background-color: #369681;
 font-weight:bold;
 font-size:110%;
 cursor:pointer;
 padding:8px;
}
</style>
</head>
<body>

<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<div class="contenedor">
<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="profesores.php">Registro</a></td>
  <td><a href="agregar_profesor.php">Agregar</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<div class="formulario">
 <form action="#" method="post" enctype="multipart/form-data"><!--Codificacion de archivo-->
 
<table class="form"> 
<tr>
 <td colspan="2"><h1>Nuevo Profesor</h1></td>
</tr>
<tr>
 <td><p>Nip: </p><input type="number" name="nie" placeholder="Nit" min="100000" max="900000" required></td>
 <td></td>
</tr>
<tr>
 <td><p>Nombre: </p><input type="text" name="nombre" placeholder="Nombre" required></td>
 <td><p>Apellidos:</p><input type="text" name="apellidos" placeholder="Apellidos" required></td>
</tr>
<tr>
 <td>
 <p>Sexo:</p>
 <select name="sexo" required>
  <option value="M">Masculino</option>
  <option value="F">Femenina</option>
 </select>
 </td>
 <td><p>Imagen:</p><input type="file" name="foto"></td>
</tr>
<tr>
 <td> 
 <p>Curso:</p><!--Select Curso-->
  <select name="curso">
  <?php include '../conexion.php';
  $result=mysqli_query($conexion, "SELECT * FROM curso");
  while ($cursos=mysqli_fetch_array($result)){ ?>
   <option value="<?php echo $cursos['id_curso']; ?>"><?php echo $cursos['nombre_curso']; ?></option>
  <?php } ?>
  </select>
 </td>
 <td>
  <p>Asignatura:</p><!--Select Asignatura-->
  <select name="asignatura">
  <?php include '../conexion.php';
  $result=mysqli_query($conexion, "SELECT * FROM asignatura");
  while ($asignaturas=mysqli_fetch_array($result)){ ?>
   <option value="<?php echo $asignaturas['id_asignatura']; ?>"><?php echo $asignaturas['nombre_asignatura']; ?></option>
  <?php } ?>
  </select>
 </td>
</tr>
<tr>
 <td colspan="2"><center><input type="submit" value="Registrar" name="registrar"></center></td>
</tr>
</table>
</form>

 </div>
</div>

<?php
if(isset($_POST['registrar'])){ 
 $nie=$_POST['nie'];
 $nombre=$_POST['nombre'];
 $apellidos=$_POST['apellidos'];
 $sexo=$_POST['sexo'];
 $asignatura=$_POST['asignatura'];
 $curso=$_POST['curso'];
 $imagen="";
}

if(isset($_FILES['foto'])){
 $file=$_FILES['foto'];
 $nombre_file=$file['name'];
 $tipo=$file['type'];
 $ruta_provisional=$file['tmp_name']; //Nombre y ubicación temporal
 $carpeta="../fotos/";

if($imagen != "" && $tipo != "image/png" && $tipo != "image/jpp" && $tipo != "image/jpeg" && $tipo != "image/gif"){
 echo "<script>alert('Selecciona un archivo que sea una imagen.');</script>";
 } else {
  $src=$carpeta.$nombre_file;
  move_uploaded_file($ruta_provisional, $src); 
  $imagen="../fotos/".$nombre_file;  
 }
}

//Verificar nit
include '../conexion.php';

$result_pr=mysqli_query($conexion, "SELECT * FROM profesor WHERE id_curso = '$curso'");
if(mysqli_num_rows($result_pr) > 0){
 echo "<script>alert('Ya existe un orientador para este curso, seleccione otro.');</script>";
} else { 
$validar=mysqli_query($conexion, "SELECT * FROM profesor WHERE nie_profesor = '$nie'");
$consulta=mysqli_num_rows($validar);
 
if($consulta != 0){ //Si 
 echo "<script>alert('El número de NIP ya encuentra registrado, verifique que no se haya equivocado.');</script>";
} else { //Ingresar
 $result=mysqli_query($conexion, "INSERT INTO profesor (nie_profesor, nombre_profesor, apellidos_profesor, genero, id_asignatura, 
 id_curso, imagen_profesor)  VALUES ('$nie','$nombre','$apellidos','$sexo','$asignatura','$curso','$imagen')");
 }
}

if($result == true){
 $usuario=$nie."@mined.sv";
 $contraseña=rand(1, 100000);
}
 
//id_profesor
include '../conexion.php';
$results=mysqli_query($conexion, "SELECT * FROM profesor WHERE nie_profesor = '$nie'");
$registro=mysqli_fetch_array($results);
$id_profesor=$registro['id_profesor'];

//Insertar.
include '../conexion.php';
$sql="INSERT INTO usuario_profesor (id_profesor, usuario, contraseña) VALUES ('$id_profesor','$usuario','$contraseña')";
$result=mysqli_query($conexion, $sql);

//profesor_responsailidades
$result_responsabilidades=mysqli_query($conexion, "INSERT INTO profesor_responsabilidad (id_profesor, id_curso, id_asignatura) VALUES ('$id_profesor','$curso','$asignatura')");
?>
</body>
</html>
