<html>
<head>
<meta charset="utf-8">
<title>Editar Profesor</title>
</head>
<style>
*{
 margin:0;
 padding:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
/*Div contenedor*/
.contenedor{
 width:100%;
 height:100vh;
 display:flex;
 align-items:center;
 justify-content:center;
 background-color:#f1f0fa;
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833 ;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
/*Efecto hover*/
.nav tr td a:hover{
 color:yellow;
}
.nav tr td a{
 font-size:115%;
}
.nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 padding:0;
 text-align:left;
}
a{
 color: white;
 text-decoration:none;
}

/*Div formulario*/
.formulario{
 width: 900px;
 height: 450px;
 background-color: #CCD1D1;
 border-radius:1%;
 box-shadow:0px 0px 20px  #3498db;
 overflow:hidden;
 margin-top:8%;
}
/*Tabla form*/
.form{
 width:100%;
 height:100%;
 background:white;
 border-collapse:collapse;
 overflow:hidden;
}
/*Titulo y parrafos*/
h1{
 font-size:225%;
 text-align:center;
 color: #324eb6 ;
}
p{
 font-size:110%;
 margin-left:7%;
}
label{ font-size:110%; }
/*Inputs*/
input[type=text],select, input[type=file]{
 margin-left:7%;
 width:80%;
 height:35%;
 font-size:100%; 
}
input[type=submit]{ 
 width:20%;
 height:100%;
 background-color: #369681;
 font-weight:bold;
 font-size:100%;
 padding:8px;
 cursor:pointer;
}
select[name=mantener]{ 
 width:15%;
 height:5%;
 font-size:100%;
}
</style>
<body>

<?php
//Recibir usuario
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<?php
//Recuperamos el id_profesor enviado por $_GET al presionar el enlace y seleccionamos todos los datos
$id_profesor=$_GET['id_profesor'];
include '../conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM profesor p INNER JOIN curso c ON p.id_curso = c.id_curso INNER JOIN asignatura a ON p.id_asignatura = a.id_asignatura WHERE id_profesor = '$id_profesor'");
$datos=mysqli_fetch_array($result);
$id_profesor=$datos['id_profesor'];
?>

<div class="contenedor">
<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="profesores.php">Registro</a></td>
  <td><a href="editar_profesor.php?id_profesor=<?php echo $id_profesor; ?>">Actualizar</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<div class="formulario">
<table class="form">

<tr>
 <td rowspan="5" width="30%">
 <center><img src="<?php echo $datos['imagen_profesor']; ?>" width="85%" alt="No hay imagen disponible."><br>
 <!--Formulario Para Editar datos del Profesor-->
 <form action="#" method="post" enctype="multipart/form-data"><br>
  <label>Mantener imagen: </label><br>
  <select name="mantener">
   <option value="si">Si</option>
   <option value="no">No</option>
  </select></center></td> 
 <td colspan="2"><h1>Editar Información</h1></td>
</tr>
  
<tr>
 <td width="35%">
  <p>Nombre:</p>
  <input type="text" name="nombre" value="<?php echo $datos['nombre_profesor']; ?>" placeholder="Nombre" required>
 </td>
 <td>
  <p>Apellidos:</p>
  <input type="text" name="apellidos" value="<?php echo $datos['apellidos_profesor']; ?>" placeholder="Apellidos" required>
 </td>
</tr>

<tr>
 <td>
  <p>Sexo:</p>
  <select name="sexo" required>
   <option value="M">Masculino</option>
   <option value="F">Femenina</option>
  </select>
 </td>
 <td> 
  <p>Cambiar Imagen:</p>
  <input type="file" name="foto">
 </td>
</tr>

<tr>
 <td> <p>Curso:</p>
 <!--Curso-->
 <select name="curso" disabled>
  <option value="<?php echo $datos['id_curso']; ?>"><?php echo $datos['nombre_curso']; ?></option>
  <?php include '../conexion.php';
  $result=mysqli_query($conexion, "SELECT * FROM curso");
  while ($cursos=mysqli_fetch_array($result)){ ?>
   <option value="<?php echo $cursos['id_curso']; ?>"><?php echo $cursos['nombre_curso']; ?></option>
  <?php } ?>
 </select>
 </td>
 <td>
 <p>Asignatura:</p>
  <!--Asignatura-->
  <select name="asignatura" disabled>
   <option value="<?php echo $datos['id_asignatura']; ?>"><?php echo $datos['nombre_asignatura']; ?></option>
   <?php include '../conexion.php';
   $result=mysqli_query($conexion, "SELECT * FROM asignatura");
   while ($asignaturas=mysqli_fetch_array($result)){ ?>
    <option value="<?php echo $asignaturas['id_asignatura']; ?>"><?php echo $asignaturas['nombre_asignatura']; ?></option>
   <?php } ?>
  </select>
 </td>
</tr>

<tr>
 <td colspan="3"><center><input type="submit" value="Actualizar" name="actualizar"></center></td>
</tr>

  </table>
 </div>
</div>

<?php
//Recuperar la imagen actual
include '../conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM profesor WHERE id_profesor = '$id_profesor'");
$imagen_actual=mysqli_fetch_array($result);
$img_ac=$imagen_actual['imagen_profesor'];
  
//Guardar la imagen actual
if($_POST){
 $mantener=$_POST['mantener'];
 if($mantener == "si"){
  $imagen=$img_ac;
 } else {
  $imagen="";
 }
}

//Recibir datos 
if(isset($_POST['actualizar'])){
 $nombre=$_POST['nombre'];
 $apellidos=$_POST['apellidos'];
 $sexo=$_POST['sexo'];
 $asignatura=$_POST['asignatura'];
 $curso=$_POST['curso'];
}

//Recibimos la imagen
if(isset($_FILES['foto'])){
 $file=$_FILES['foto'];
 $nombre_file=$file['name'];
 $tipo=$file['type'];
 $ruta_provisional=$file['tmp_name']; 
 $carpeta="../fotos/";
 
//Verificar que se imagen
if($tipo != "image/jpg" && $tipo != "image/png" && $tipo != "image/jpeg" && $tipo != "image/gif"){
 echo "<script>alert('El archivo seleccionado no es una imagen.');script>";
} else {
 $src=$carpeta.$nombre_file;
 move_uploaded_file($ruta_provisonal, $src); 
 $imagen="../fotos/".$nombre_file;
}
 
//Actualizar
include '../conexion.php';
$result=mysqli_query($conexion, "UPDATE `profesor` SET `nombre_profesor` = '$nombre', `apellidos_profesor` = '$apellidos', `genero` = '$sexo', `imagen_profesor` = '$imagen' WHERE `profesor`.`id_profesor` = '$id_profesor'");
}
?>
</body>
</html> 
