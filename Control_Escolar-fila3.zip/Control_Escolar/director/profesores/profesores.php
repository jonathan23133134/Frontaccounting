<html>
 <head>
 <meta charset="utf-8">
 <title>Administrar Profesores</title>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
body{
 background-color:#f1f0fa;
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color:#1c2833;
 color:white;
 margin:0%;
 box-shadow:none;
 position:fixed;
 left:0; top:0;
 border-top:4px solid #1c2833;
 border-bottom:8px solid grey;
 }
 .nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 border:0;
 padding:0;
 text-align:left;
}
.nav tr td a{
 font-size:115%;
 color: white;
 text-decoration:none;
}
.nav tr td a:hover{
 color:yellow;
}
/*Tabla de registros*/
.table{
 width:800px;
 background-color:white;
 text-align:left;
 border-collapse:collapse;
 margin:10.5% auto;
 font-size:115%;
 box-shadow:0px 0px 20px black;
 border:1px solid black;
}
.table tr{
 text-align:center;
 border:1px solid black;
}
.table th ,td {
 padding:20px;
 border:1px solid black;
}
/*Cabeceras*/
.table th{
 background-color:#246355;
 border-bottom:solid 5px #0F362D;
 color:white;
}
.table tr:nth-child(even){
 background-color:#ddd;
} 
.table tr:hover{
background-color:lightblue;
}
/*Enlaces*/
table td #acc{
 background:#e74c3c;
 text-decoration:none;
 padding:7px;
 color:black;
 font-size:110%;
 border-radius:10%;
}
/*Pie*/
.pie{
 width:100%;
 height:10%;
 background-color:#273746 ;
 overflow:hidden;
 display:flex;
 align-items:center;
}
.pie h3{ 
 margin-left:5%; 
 color:white;
}
</style>
</head>
<body>

<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="#"> Actualizar</a></td>
  <td><a href="agregar_profesor.php">Agregar</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>
 
<center>
<!--Tabla de registros-->
<table class="table">
 <tr>
  <th colspan="11">
   <h1 align="center">Registro de Profesores</h1>
   <img src="../img/logo.png" width="12%">
  </th>
 </tr>
 
 <tr>
  <th>NIP</th>
  <th>Nombre</th>
  <th>Apellidos</th>
  <th>Sexo</th>
  <th>Curso</th>
  <th>Asignatura</th>
  <th colspan="4">Acción</th>
 </tr>
 
<?php 
include '../conexion.php';
$result=mysqli_query($conexion, "SELECT * FROM profesor p 
INNER JOIN curso c ON p.id_curso = c.id_curso
INNER JOIN asignatura a ON p.id_asignatura = a.id_asignatura");
 
while ($profesor=mysqli_fetch_array($result)){ ?>
 <tr>
  <td><?php echo $profesor['nie_profesor']; ?></td>
  <td><?php echo $profesor['nombre_profesor']; ?></td>
  <td><?php echo $profesor['apellidos_profesor']; ?></td>
  <td><?php echo $profesor['genero']; ?></td>
  <td><?php echo $profesor['nombre_curso']; ?></td>
  <td><?php echo $profesor['nombre_asignatura']; ?></td>
  <td><a id="acc" href="editar_profesor.php?id_profesor=<?php echo $profesor['id_profesor']; ?>">✏️</a></td>
  <td><a id="acc" href="profesores.php?id_profesor=<?php echo $profesor['id_profesor']; ?>">🗑️</a></td>
  <td><a id="acc" href="responsabilidades.php?id_profesor=<?php echo $profesor['id_profesor']; ?>">📂️</a></td>
  <td><a id="acc" href="profesores.php?id_curso=<?php echo $profesor['id_curso']; ?>">🧑‍🎓</a></td>
 </tr>
 <?php } ?>
</table>
</center>

<?php
//Eliminar
if($_GET['id_profesor']){
 $id_profesor=$_GET['id_profesor'];
 if(isset($id_profesor)){
 echo "<script>alert('¿Esta seguro de querer eliminar el registro?');</script>";
 $result=mysqli_query($conexion, "DELETE FROM profesor WHERE id_profesor = '$id_profesor'");
 }
}
?>

<center>
<p id="lista"></p>
<table class="table">
 <tr>
  <th colspan="10">
   <h1 align="center">Lista de Estudiantes</h1>
  </th>
 </tr>
 
 <tr>
  <th>Nie</th>
  <th>Nombre</th>
  <th>Apellidos</th>
  <th>Sexo</th>
  <th>Edad</th>
  <th>Curso</th>
 </tr>
 
<?php 
if($_GET['id_curso']){
 $id_curso=$_GET['id_curso'];
}
 
if(isset($id_curso)){
$result=mysqli_query($conexion, "SELECT * FROM estudiante 
INNER JOIN curso ON estudiante.id_curso = curso.id_curso
WHERE curso.id_curso = '$id_curso'");

if($result == true && mysqli_num_rows($result) != 0){
 echo "<script>alert('La lista de estudiantes aparece en la parte inferior.');</script>";
while ($profesor=mysqli_fetch_array($result)){ ?>
 <tr>
  <td><?php echo $profesor['nie']; ?></td>
  <td><?php echo $profesor['nombre']; ?></td>
  <td><?php echo $profesor['apellidos']; ?></td>
  <td><?php echo $profesor['sexo']; ?></td>
  <td><?php echo $profesor['edad']; ?></td>
  <td><?php echo $profesor['nombre_curso']; ?></td>
 </tr>
<?php } } else {
 echo "<script>alert('No hay estudiantes matriculados en este curso.')</script>;";
 echo "<tr><td colspan='6'><font color='blue'><b>No hay estudiantes matriculados en este curso.</b></font></td></tr>";
} }?>
</table>
</center>

<div class="pie">
 <h3>© Complejo Educativo Residencial Altavista</h3>
</div>

</body>
</html>
