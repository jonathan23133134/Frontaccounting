<html>
 <head>
 <meta charset="utf-8">
 <title>Administrar Estudiantes</title>
</head>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
body{
 background-color:#f1f0fa;
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:23px;
 overflow:hidden;
 background-color: #1c2833;
 color:white;
 margin:0%;
 box-shadow:none;
 border-top:4px solid  #1c2833;
 border-bottom:8px solid grey;
 position:fixed;
 left:0; top:0;
}
.nav tr td a{
 font-size:115%;
}
.nav tr td a:hover{
 color:yellow;
}
.nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 padding:7px;
 text-align:left;
 border:0;
}
/*Tabla de registros*/
.table{
 background-color:white;
 text-align:left;
 width:990px;
 border-collapse:collapse;
 margin-top:10.5%;
 margin-bottom:5%;
 font-size:115%;
 box-shadow:0px 0px 20px black;
 border:1px solid black;
}
.table tr{
 border:1px solid black;
 text-align:center;
}
.table th ,td {
 border:1px solid black;
 padding:20px;
}
.table th{
 background-color:#246355;
 border-bottom:solid 5px #0F362D;
 color:white;
}
.table tr:nth-child(even){
 background-color:#ddd;
} 
.table tr:hover{ background-color: lightblue; }
table td a{
 text-decoration:none;
 padding:5px;
 color:white;
}
select{
 width:30%;
 height:30px;
 font-size:100%;
 text-align:center;
}
input{
 width:20%;
 height:33px;
 background-color:#3498db;
 font-size:100%;
 cursor:pointer;
}
</style>
<body>
 
<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="20%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="consulta.php"> Consulta</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

 
<!--Tabla de Registro-->
<center>
<table class="table">
<tr>
 <th colspan="10">
  <h1 align="center">Registro de Estudiantes</h1>
  <img src="../img/logo.png" width="12%"><br><br>
 
  <!-- Select curso-->
  <form action="#" method="post">
  <label>Curso: &nbsp;</label> <select name="curso">
   <?php include '../conexion.php';
   $result=mysqli_query($conexion, "SELECT * FROM curso");
   while ($cursos=mysqli_fetch_array($result)){ ?>
    <option value="<?php echo $cursos['id_curso']; ?>"><?php echo $cursos['nombre_curso']; ?></option>
   <?php } ?>
  </select>
  <input type="submit" value="Buscar" name="filtrar"> 
 </th>
</tr>
 
<tr>
 <th>Id</th>
 <th>Nie</th>
 <th>Nombre</th>
 <th>Apellidos</th>
 <th>Sexo</th>
 <th>Edad</th>
 <th>Curso</th>
</tr>

<!--Mostrar-->
<?php
if(isset($_POST['filtrar'])){
 $id_curso=$_POST['curso'];
 $result=mysqli_query($conexion, "SELECT * FROM estudiante  
 INNER JOIN curso ON estudiante.id_curso = curso.id_curso 
 WHERE estudiante.id_curso = '$id_curso' ORDER BY id_estudiante ASC");
 if($result == true && mysqli_num_rows($result) == 0){
  echo "<tr><td colspan='8'><font color='blue'><b>No hay estudiantes matriculados en el curso seleccionado.</b></font></td></tr>";
 } else {
 while($estudiante=mysqli_fetch_array($result)){ ?>
  <tr>
   <td><?php echo $estudiante['id_estudiante']; ?></td>
   <td><?php echo $estudiante['nie']; ?></td>
   <td><?php echo $estudiante['nombre']; ?></td>
   <td><?php echo $estudiante['apellidos']; ?></td>
   <td><?php echo $estudiante['sexo']; ?></td>
   <td><?php echo $estudiante['edad']; ?></td>
   <td><?php echo $estudiante['nombre_curso']; ?></td>
  </tr>
<?php } } } ?>
 </table>
</center>

</body>
</html>
