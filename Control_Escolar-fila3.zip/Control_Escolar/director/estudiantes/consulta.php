<html>
 <head>
 <meta charset="utf-8">
 <title>Consultar Información</title>
</head>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
body{
 background-color:#f1f0fa;
}
/*Tabla Nav*/
.nav{
width:100%;
height:23px;
overflow:hidden;
background-color: #1c2833;
color:white;
margin:0%;
box-shadow:none;
border-top:4px solid  #1c2833;
border-bottom:8px solid grey;
position:fixed;
left:0; top:0;
}
.nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 padding:7px;
 text-align:left;
 border:0;
}
.nav tr td a{
 font-size:115%;
}
.nav tr td a:hover{
 color:yellow;
}
.contenedor{
width:100%;
height:100vh;
display:flex;
align-items:center;
justify-content:center;
}
.buscar{
width:600px;
height:250px;
border:2px solid black;
border-radius:3%;
overflow:hidden;
background:#76d7c4;
box-shadow:0px 0px 15px black;
}
.buscar h1{
margin-top:7%;
}
.buscar a{
box-shadow:0px 0px 5px yellow;
font-size:200%;
}
.buscar label{
font-size:120%;
}
input[type="submit"]{
background: #e74c3c;
padding:5px 10px;
cursor:pointer;
font-weight:bold;
color:black;
}
/*Tablas de registros*/
.table{
 background-color:white;
 text-align:left;
 width:990px;
 border-collapse:collapse;
 margin-bottom:5%;
 font-size:115%;
 box-shadow:0px 0px 20px black;
 border:1px solid black;
}
.table tr{
 border:1px solid black;
 text-align:center;
}
.table th ,td {
 border:1px solid black;
 padding:12px;
}
.table th{
 background-color:#246355;
 border-bottom:solid 5px #0F362D;
 color:white;
}
.table tr:nth-child(even){
 background-color:#ddd;
} 
.table tr:hover{ background-color: lightblue; }
table td a{
 text-decoration:none;
 padding:5px;
 color:white;
}
input{
 height:40px;
 text-align:center;
 font-size:110%;
}
</style>
<body>
 
<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="17%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="estudiantes.php">Estudiantes</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<div class="contenedor">
 <div class="buscar">
  <form action="#" method="post"><center>
  <h1>Consultar Datos</h1><br>
  <label>NIE:</label>&ensp;&ensp;
  <input type="number" name="nie" min="1">&ensp;&ensp;
  <input type="submit" value="Realizar Consulta"><br><br>
  <a href="estudiantes.php">↩️</a>&ensp;&ensp;<a href="#datos">⬇️</a></center>
 </div><p id="datos"></p>
</div>

<!--Tabla de Registro-->
<center>
<table class="table">
<tr>
 <th colspan="10"><h1 align="center">Datos Personales</h1></th>
</tr>
<tr>
 <th>Nie</th>
 <th>Nombre</th>
 <th>Apellidos</th>
 <th>Sexo</th>
 <th>Edad</th>
 <th>Curso</th>
 <th>Orientador</th>
 <th>Usuario</th>
 <th>Contraseña</th>
</tr>
<?php
//Recibir el nie
$c="<font color='blue'>0</font>";
$a="<font color='green'>Aprobado</font>";
$r="<font color='red'>Reprobado</font>";
$sc="Sin Calificar";

include '../conexion.php';
if(isset($_POST['nie'])){
$nie_estudiante=$_POST['nie'];
$result_nie=mysqli_query($conexion, "SELECT * FROM estudiante 
INNER JOIN curso ON curso.id_curso = estudiante.id_curso 
INNER JOIN profesor ON estudiante.id_curso = profesor.id_curso 
INNER JOIN usuario_estudiante ON estudiante.id_estudiante = usuario_estudiante.id_estudiante WHERE nie = '$nie_estudiante'");
 if($result == true && mysqli_num_rows($result_nie) == 0){ 
  echo "<script>alert('No hay ningun estudiante registrado con ese NIE.');</script>";
 } else {
 while($estudiante=mysqli_fetch_array($result_nie)){ 
 $id_curso=$estudiante['id_curso'];
 $id_estudiante=$estudiante['id_estudiante']; ?>
  <tr>
   <td><?php echo $estudiante['nie']; ?></td>
   <td><?php echo $estudiante['nombre']; ?></td>
   <td><?php echo $estudiante['apellidos']; ?></td>
   <td><?php echo $estudiante['sexo']; ?></td>
   <td><?php echo $estudiante['edad']; ?></td>
   <td><?php echo $estudiante['nombre_curso']; ?></td>
   <td><?php echo $estudiante['nombre_profesor']." ".$estudiante['apellidos_profesor']; ?></td>
   <td><?php echo $estudiante['usuario']; ?></td>
   <td><?php echo $estudiante['contraseña']; ?></td>
  </tr><?php } } } ?>
 </table>

<!--Periodo 1-->
<table class="table" width="1000px">
<tr>
 <th colspan="6"><h1 align="center">Notas</h1></th>
</tr>
<tr>
 <th rowspan="2">Asignatura</th>
 <th colspan="3">Periodo 1</th>
 <th rowspan="2">Promedio</th>
 <th rowspan="2">Estado</th>
</tr>
<tr>
 <th>Nota 1</th>
 <th>Nota 2</th>
 <th>Nota 3</th>
</tr>

<!--Periodo1-->
<?php
if(isset($_POST['nie'])){
 $nie_estudiante=$_POST['nie'];
 
 $result=mysqli_query($conexion, "SELECT * FROM profesor_responsabilidad 
 INNER JOIN asignatura ON profesor_responsabilidad.id_asignatura = asignatura.id_asignatura
 WHERE id_curso = '$id_curso'");
 
if(mysqli_num_rows($result) != 0){
 while($asignaturas=mysqli_fetch_array($result)){ 
 $id_asignatura=$asignaturas['id_asignatura']; 
 $result_c=mysqli_query($conexion, "SELECT * FROM calificacion 
 INNER JOIN asignatura ON calificacion.id_asignatura = asignatura.id_asignatura 
 WHERE calificacion.id_estudiante = '$id_estudiante' AND calificacion.id_asignatura = '$id_asignatura' AND id_periodo = '1'");
 $notas=mysqli_fetch_array($result_c); ?>
  <tr>
   <td><?php echo $asignaturas['nombre_asignatura']; ?></td>
   <td><?php if(isset($notas['nota1'])){ echo $notas['nota1']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['nota2'])){ echo $notas['nota2']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['nota3'])){ echo $notas['nota3']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['promedio'])){ echo $notas['promedio']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['promedio']) && $notas['promedio'] >= 7){ echo $a; } 
   elseif ($notas['promedio']==""){ echo $sc; } 
   else { echo $r; } ?></td>
  </tr><?php } } } ?>
 </table>
<!---->


<!--Periodo 2-->
<table class="table" width="1000px">
<tr>
 <th colspan="6"><h1 align="center">Notas</h1></th>
</tr>
<tr>
 <th rowspan="2">Asignatura</th>
 <th colspan="3">Periodo 2</th>
 <th rowspan="2">Promedio</th>
 <th rowspan="2">Estado</th>
</tr>
<tr>
 <th>Nota 1</th>
 <th>Nota 2</th>
 <th>Nota 3</th>
</tr>

<?php
if(isset($_POST['nie'])){
 $nie_estudiante=$_POST['nie'];
 
 $result=mysqli_query($conexion, "SELECT * FROM profesor_responsabilidad 
 INNER JOIN asignatura ON profesor_responsabilidad.id_asignatura = asignatura.id_asignatura
 WHERE id_curso = '$id_curso'");
 
if(mysqli_num_rows($result) != 0){
 while($asignaturas=mysqli_fetch_array($result)){ 
 $id_asignatura=$asignaturas['id_asignatura']; 
 $result_c=mysqli_query($conexion, "SELECT * FROM calificacion INNER JOIN asignatura ON calificacion.id_asignatura = asignatura.id_asignatura WHERE calificacion.id_estudiante = '$id_estudiante' AND calificacion.id_asignatura = '$id_asignatura' AND id_periodo = '2'");
 $notas=mysqli_fetch_array($result_c);
 ?>
  <tr>
   <td><?php 
   echo $asignaturas['nombre_asignatura']; ?></td>
   <td><?php if(isset($notas['nota1'])){ echo $notas['nota1']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['nota2'])){ echo $notas['nota2']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['nota3'])){ echo $notas['nota3']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['promedio'])){ echo $notas['promedio']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['promedio']) && $notas['promedio'] >= 7){ echo $a; } 
   elseif ($notas['promedio']==""){ echo $sc; } 
   else { echo $r; } ?></td>
  </tr><?php } } } ?>
 </table>

<!--Periodo 3-->
<table class="table" width="1000px">
<tr>
 <th colspan="6"><h1 align="center">Notas</h1></th>
</tr>
<tr>
 <th rowspan="2">Asignatura</th>
 <th colspan="3">Periodo 3</th>
 <th rowspan="2">Promedio</th>
 <th rowspan="2">Estado</th>
</tr>
<tr>
 <th>Nota 1</th>
 <th>Nota 2</th>
 <th>Nota 3</th>
</tr>

<?php
if(isset($_POST['nie'])){
 $nie_estudiante=$_POST['nie'];
 
 $result=mysqli_query($conexion, "SELECT * FROM profesor_responsabilidad 
 INNER JOIN asignatura ON profesor_responsabilidad.id_asignatura = asignatura.id_asignatura
 WHERE id_curso = '$id_curso'");
 
if(mysqli_num_rows($result) != 0){
 while($asignaturas=mysqli_fetch_array($result)){ 
 $id_asignatura=$asignaturas['id_asignatura']; 
 $result_c=mysqli_query($conexion, "SELECT * FROM calificacion INNER JOIN asignatura ON calificacion.id_asignatura = asignatura.id_asignatura WHERE calificacion.id_estudiante = '$id_estudiante' AND calificacion.id_asignatura = '$id_asignatura' AND id_periodo = '3'");
 $notas=mysqli_fetch_array($result_c); ?>
  <tr>
   <td><?php 
   echo $asignaturas['nombre_asignatura']; ?></td>
   <td><?php if(isset($notas['nota1'])){ echo $notas['nota1']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['nota2'])){ echo $notas['nota2']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['nota3'])){ echo $notas['nota3']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['promedio'])){ echo $notas['promedio']; } else { echo $c; }?></td>
   <td><?php if(isset($notas['promedio']) && $notas['promedio'] >= 7){ echo $a; } 
   elseif ($notas['promedio']==""){ echo $sc; } 
   else { echo $r; } ?></td>
  </tr><?php } } } ?>
 </table>

<!--Periodo 4-->
<table class="table" width="1000px">
<tr>
 <th colspan="6"><h1 align="center">Notas</h1></th>
</tr>
<tr>
 <th rowspan="2">Asignatura</th>
 <th colspan="3">Periodo 4</th>
 <th rowspan="2">Promedio</th>
 <th rowspan="2">Estado</th>
</tr>
<tr>
 <th>Nota 1</th>
 <th>Nota 2</th>
 <th>Nota 3</th>
</tr>

<?php
if(isset($_POST['nie'])){
 $nie_estudiante=$_POST['nie'];
 
 $result=mysqli_query($conexion, "SELECT * FROM profesor_responsabilidad 
 INNER JOIN asignatura ON profesor_responsabilidad.id_asignatura = asignatura.id_asignatura
 WHERE id_curso = '$id_curso'");
 
if(mysqli_num_rows($result) != 0){
 while($asignaturas=mysqli_fetch_array($result)){ 
 $id_asignatura=$asignaturas['id_asignatura']; 
 $result_c=mysqli_query($conexion, "SELECT * FROM calificacion INNER JOIN asignatura ON calificacion.id_asignatura = asignatura.id_asignatura WHERE calificacion.id_estudiante = '$id_estudiante' AND calificacion.id_asignatura = '$id_asignatura' AND id_periodo = '4'");
 $notas=mysqli_fetch_array($result_c); ?>
  <tr>
   <td><?php echo $asignaturas['nombre_asignatura']; ?></td>
   <td><?php if(isset($notas['nota1'])){echo $notas['nota1']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['nota2'])){echo $notas['nota2']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['nota3'])){echo $notas['nota3']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['promedio'])){echo $notas['promedio']; } else { echo $c; } ?></td>
   <td><?php if(isset($notas['promedio']) && $notas['promedio'] >= 7){ echo $a; } 
   elseif ($notas['promedio']==""){ echo $sc; } 
   else { echo $r; } ?></td>
  </tr><?php } } } ?>
 </table>
</center>

</body>
</html>
