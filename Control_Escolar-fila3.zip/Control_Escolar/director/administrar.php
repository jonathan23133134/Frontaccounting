<html>
 <head>
 <meta charset="utf-8">
 <title>Administrar</title>
 <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../login.php"); 
}
?>

<br><label for="menu-lateral" class="icono">☰</label>
<input type="checkbox" id="menu-lateral">

<div class="nav"><a href="cerrar.php">🔒 Cerrar Sesión</a></div>

<!-- Menú Lateral -->
<div class="menu">
 <div class="menu-lateral">
  <table>
  <tr><th>Administrar 🛠️</th></tr>
  <tr><td><a href="profesores/profesores.php">👨‍🏫 Profesores</a></td></tr>
  <tr><td><a href="estudiantes/estudiantes.php">👨‍🎓 Estudiantes</a></td></tr>
  <tr><td><a href="asignaturas/asignaturas.php">📚 Asignaturas</a></td></tr>
  <tr><td><a href="cursos/grados.php">💻 Grados</a></td></tr>
  <tr><td><a href="calificaciones/registro_calificaciones.php">✍️ Notas</a></td></tr>
  <tr><td><a href="usuarios/usuarios.php">🙎‍♂️ Usuarios</a></td></tr>
  </table>
  <label for="menu-lateral" class="icono">X</label>
 </div>
</div>

<center><!--1-->
<section>

<center><!--2-->
 <div id="titulo">
  <h1>Control Escolar</h1>
 </div><br><br>
 <img src="img/logo.png" width="25%" id="img">
</center><!--2-->
 
<div class="datos"><br>

<a href="profesores/profesores.php">
 <div id="datos1">
  <img src="img/profesor.png" width="35%"><br>&nbsp;Docentes<br>
  <?php include 'conexion.php';
  $result=mysqli_query($conexion, "SELECT COUNT(*) total FROM profesor");
  $registros=mysqli_fetch_array($result);
  echo $registros['total'];
  ?>
 </div>
</a>
 
<a href="estudiantes/estudiantes.php">
 <div id="datos2">
  <img src="img/alumno.png" width="40%"><br>&nbsp;Alumnos<br>
  <?php
  $result=mysqli_query($conexion, "SELECT * FROM estudiante");
  echo mysqli_num_rows($result);
  ?>
 </div>
</a>
 
<a href="cursos/grados.php">
 <div id="datos3">
  <img src="img/curso.png" width="35%"><br>&nbsp;Cursos<br>
  <?php 
  $result=mysqli_query($conexion, "SELECT * FROM curso");
  echo mysqli_num_rows($result);
  ?>
 </div>
</a>
 
<a href="asignaturas/asignaturas.php">
 <div id="datos4">
  <img src="img/materia.png" width="35%"><br>&nbsp;Materias<br>
  <?php 
  $result=mysqli_query($conexion, "SELECT * FROM asignatura");
  echo mysqli_num_rows($result);
  ?>
 </div>
</a>

</section>
</center><!--1-->

</body>
</html>

