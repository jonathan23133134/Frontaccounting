<html>
 <head>
 <meta charset="utf-8">
 <title>Registro Calificación</title>
</head>
<style>
*{
 padding:0;
 margin:0;
 box-sizing:border-box;
 font-family:'ubuntu';
}
body{
 background-color:#f1f0fa;
}
/*Tabla Nav*/
.nav{
 width:100%;
 height:20px;
 overflow:hidden;
 background-color: #1c2833;
 color:white;
 margin:0%;
 box-shadow:none;
 border-top:4px solid  #1c2833;
 border-bottom:8px solid grey;
 position:fixed;
 left:0; top:0;
}
.nav tr td img{
 margin-left:5%;
 padding:3px 3px;
}
.nav td{
 padding:0;
 border:0;
 text-align:left;
}
.nav tr td a{
 font-size:115%;
}
.nav tr td a:hover{
 color:yellow;
}
/*Tabla de registro*/
.table{
 background-color:white;
 text-align:left;
 width:1000px;
 border-collapse:collapse;
 margin:10.5%;
 font-size:115%;
 border:1px solid black;
 box-shadow:0px 0px 20px black;
}
.table tr{
 border:1px solid black;
 text-align:center;
}
.table th ,td {
 padding:15px;
  border:1px solid black;
}
.table th{
 background-color:#246355;
 border-bottom:solid 5px #0F362D;
 color:white;
}
.table tr:nth-child(even){
 background-color:#ddd;
} 
table td a{
 text-decoration:none;
 padding:5px;
 color:white;
}
select{
 width:25%;
 height:30px;
 font-size:100%;
 text-align:center;
}
input{
 width:15%;
 height:30px;
 background:#e74c3c;
 font-size:100%;
 cursor:pointer;
 border-radius:10%;
}
</style>
<body>
 
<?php
session_start();
$usuario=$_SESSION['usuario'];
if($usuario == ""){
 header("location: ../../login.php"); 
}
?>

<!--Tabla Nav-->
<table class="nav"> 
 <tr>
  <td><img src="../img/newlogo.png" width="17%"></td>
  <td><a href="../administrar.php"> Inicio</a></td>
  <td><a href="../cerrar.php">🔒 Salir</a></td>
 </tr>
</table>

<!--Tabla de Registro-->
<center>
<table class="table">

<tr>
 <th colspan="4">
  <h1 align="center">Calificaciones Registradas</h1>
 </th>
<tr> 

<tr>
 <td colspan="4">
  <!--Select de cursos-->
  <h3>1. Seleccionar Curso:</h3>
  <form action="#" method="post">
   <select name="id_curso" required >
   <?php
    include '../conexion.php';
    $result=mysqli_query($conexion, "SELECT * FROM curso");
    while($cursos=mysqli_fetch_assoc($result)){ ?>
     <option value="<?php echo $cursos['id_curso']; ?>"><?php echo $cursos['nombre_curso']; ?></option>
   <?php } ?>
   </select> &nbsp;&nbsp;&nbsp;<input type="submit" value="Seleccionar">
  </form>
 </td>
</tr>

<tr>
 <td colspan="4"><!--Buscar Registro-->
  <!--Estudiantes del curso selecionado-->
  <h3>2. Seleccionar un estudiante:</h3>
  <form action="#" method="post">
   <select name="id_estudiante" required>
   <?php
   if(isset($_POST['id_curso'])){
    $id_curso=$_POST['id_curso'];
   } 
   include '../conexion.php';
   $result=mysqli_query($conexion, "SELECT * FROM estudiante WHERE id_curso = '$id_curso'");
    while($estudiante=mysqli_fetch_array($result)){ ?>
     <option value="<?php echo $estudiante['id_estudiante']; ?>"><?php echo $estudiante['nombre']; ?></option>
   <?php } ?>
   </select>&nbsp;&nbsp;&nbsp;<input type="submit" value="Buscar">
  </form>
 </td>
</tr>
 
<tr> 
 <th>Nie</th>
 <th>Estudiante</th>
 <th>Curso</th>
 <th>Profesor</th>
</tr>
  
<?php
//Datos del estudiante seleccionado
if(isset($_POST['id_estudiante'])){
 $id_estudiante=$_POST['id_estudiante'];
 include '../conexion.php';
 $result=mysqli_query($conexion, "SELECT * FROM calificacion c 
 INNER JOIN estudiante e ON c.id_estudiante = e.id_estudiante
 INNER JOIN curso g ON c.id_curso = g.id_curso
 INNER JOIN asignatura a ON c.id_asignatura = a.id_asignatura 
 INNER JOIN profesor p ON c.id_profesor = p.id_profesor
 INNER JOIN periodo pd ON c.id_periodo = pd.id_periodo
 WHERE c.id_estudiante = '$id_estudiante'");
 $datos=mysqli_fetch_array($result);
  if(isset($datos)){ ?>
   <tr>
    <td><?php echo $datos['nie']; ?></td>
    <td><?php echo $datos['nombre']." ".$datos['apellidos']; ?></td>
    <td><?php echo $datos['nombre_curso']; ?></td>
    <td><?php echo $datos['nombre_profesor']." ".$datos['apellidos_profesor']; ?></td>
  </tr>
<?php } else {
  echo "<tr><td colspan='4'>No hay calificaciones registradas para el estudiante seleccionado.</td></tr>";
} } ?>
 
<tr>
 <th>Periodo</th>
 <th>Asignatura</th>
 <th>Promedio</th>
 <th>Estado</th>
</tr>
 
<?php
//Notas
if(isset($_POST['id_estudiante'])){
 $id_estudiante=$_POST['id_estudiante'];
 include '../conexion.php';
 $result=mysqli_query($conexion, "SELECT * FROM calificacion c 
 INNER JOIN estudiante e ON c.id_estudiante = e.id_estudiante
 INNER JOIN curso g ON c.id_curso = g.id_curso
 INNER JOIN asignatura a ON c.id_asignatura = a.id_asignatura 
 INNER JOIN profesor p ON c.id_profesor = p.id_profesor
 INNER JOIN periodo pd ON c.id_periodo = pd.id_periodo
 WHERE c.id_estudiante = '$id_estudiante'");
 if($result == true && mysqli_num_rows($result) > 0){
 while($datos=mysqli_fetch_assoc($result)) { ?>
  <tr>
   <td><?php echo $datos['nombre_periodo']; ?></td>
   <td><?php echo $datos['nombre_asignatura']; ?></td>
   <td><?php echo $datos['promedio']; ?></td>
   <td>
    <?php if($datos['promedio'] < 7 ){ 
     echo "<font color='red'>❌ Reprobado</font>"; }else{
     echo "<font color='green'>✅ Aprobado</font>";} 
     ?>
  </td>
 </tr>
<?php } } else {
   echo "<tr><td colspan='4'>No hay calificaciones registradas para el estudiante seleccionado.</td></tr>";
  } }?>
 </table>
</center>

</body>
</html>
