<?php
session_start();
$usuario = $_SESSION['usuario'];
if (!isset($usuario)) {
    header("location: ../login.php");
    exit(); 
}

include 'conexion.php'; 
// Obtener el ID del profesor en sesión
$id_profe = "SELECT id_profesor FROM usuario_profesor WHERE usuario = '$usuario'";
$result_id_profesor = mysqli_query($conexion, $id_profe);
$filid_profesor = mysqli_fetch_assoc($result_id_profesor);
$id_profesor = $filid_profesor['id_profesor'];
?>

<html>
<head>
<meta charset="utf-8">
<title>Calificación Media</title>
<style>
    *{
        margin:0;
        font-family:'ubuntu';
    }
    body{

        background-image: url('img/fondo.png');
        background-size: cover;
    }
    
    .nav{
        width:100%;
        height:20px;
        overflow:hidden;
        background-color: #1c2833;
        color:white;
        margin:0%;
        box-shadow:2px 2px 10px grey;
        left:0; top:0;
        border-top:3px solid #1c2833;
    }
    .nav tr th a:hover{
        color:yellow;
    }
    .nav tr th a{
        font-size:130%;
        text-decoration:none;
        color:white;
    }
    .nav td{
        border:0;
        text-align:left;
        padding:0;


    }


    .table{
        text-align:left;
        width:75%;
        border-collapse:collapse;
        box-shadow: 2px 3px 15px grey;
    }
    .table tr{
        text-align:center;
    }
    .table th ,td {
        padding:10px;
        border:1px solid black;
    }
    .table th{
        background-color:#246355;
        color:white;
    }

    .titulo{
        font-size:40px;
    }

    /*Inputs*/
    input[type=submit]{
        font-size:90%;
        background-color: #3b95b9;
        padding:3px 9px;
        border-radius:5%;
        cursor:pointer;
    }
    select{
        font-size:90%;
        text-align:center;
        padding:3px 9px;
        border-radius:3%;
        border:1px solid black;
        margin:1%;
    }

    .o{
        background-color: ddd;
    }
</style>
</head>
<body>

<table class="nav">
<tr>
<th width="20%"><img src="img/logo.png" width="25%"></th>
<th width="26%" class="titulo">Calificaciones Registradas</th>
<th width="10%"><a href="administrar.php">Salir</a></th>
<th width="10%"><a href="calificar_media.php">Calificar</a></th>
</tr>
</table>
<br>
<center>
<table class="table">

<td colspan="8" class="o">

<h3> Seleccionar Curso:</h3>
<form action="#" method="post">
<select name="buscar" required >

    <?php include 'conexion.php';

    $result=mysqli_query($conexion, "SELECT * FROM profesor_responsabilidad pr INNER JOIN profesor p ON pr.id_profesor = p.id_profesor 
    INNER  
    JOIN asignatura a ON pr.id_asignatura = a.id_asignatura INNER JOIN curso c ON pr.id_curso = c.id_curso INNER JOIN usuario_profesor up 
    ON 
    up.id_profesor = p.id_profesor WHERE up.usuario = '$usuario'");

    while ($fila_curso = mysqli_fetch_assoc($result)) {
        echo "<option value='" . $fila_curso['id_curso'] . "'>" . $fila_curso['nombre_curso'] . "</option>";
    }
    ?>


</select> &nbsp;&nbsp;&nbsp;<input type="submit" value="Buscar">
</form>
</td>
</tr> 

<tr>
<td colspan="8" class="o">

    <?php 
    if(isset($_POST['buscar'])){
    $termino=$_POST['buscar'];
    } 
    ?>
    
<h3>Seleccionar un estudiante:</h3>
<form action="#" method="post">
<select name="studiante" required>

    <?php include 'conexion.php';
    $result = mysqli_query($conexion, "SELECT * FROM estudiante WHERE id_curso = '$termino'");
    while ($estudiante = mysqli_fetch_array($result)) {
        echo "<option value='" . $estudiante['id_estudiante'] . "'>" . $estudiante['nombre'] . "</option>";
    }
    ?>

</select>&nbsp;&nbsp;&nbsp;<input type="submit" value="Buscar">
</form>
</td></tr>

<tr>
  
<th width="22%">Nie</th>
<th width="22%">Estudiante</th>
<th width="22%">Curso</th>
<th width="22%">Profesor</th>
</tr>
  
    <?php
    // Seleccionamos todos los registros actuales de la tabla calificacion de un curso en específico
    // y traemos los datos de las tablas relacionadas con INNER JOIN
    if (isset($_POST['studiante'])) {
    $id_s = $_POST['studiante'];
    include 'conexion.php';
    $result = mysqli_query($conexion, "SELECT * FROM calificacion c 
        INNER JOIN estudiante e ON c.id_estudiante = e.id_estudiante
        INNER JOIN curso g ON c.id_curso = g.id_curso
        INNER JOIN asignatura a ON c.id_asignatura = a.id_asignatura 
        INNER JOIN profesor p ON c.id_profesor = p.id_profesor
        INNER JOIN periodo pd ON c.id_periodo = pd.id_periodo
        WHERE c.id_estudiante = '$id_s'");
    $datos = mysqli_fetch_assoc($result);
    if (isset($datos)) {
        echo "<tr>";
        echo "<td>" . $datos['nie'] . "</td>";
        echo "<td>" . $datos['nombre'] . " " . $datos['apellidos'] . "</td>";
        echo "<td>" . $datos['nombre_curso'] . "</td>";
        echo "<td>" . $datos['nombre_profesor'] . " " . $datos['apellidos_profesor'] . "</td>";
        echo "</tr>";
     }
    }
    ?>
</table>
<table class="table">
<tr>
<th>Periodo</th>
<th>Asignatura</th>
<th>N1</th>
<th>N2</th>
<th>N3</th>
<th>Promedio</th>
<th>Estado</th>
<th colspan="2">Acción</th>
</tr>
 <?php
if(isset($_POST['studiante'])) {

    $id_s = intval($_POST['studiante']);
    
    include 'conexion.php';
    
    $query = "SELECT *, pd.nombre_periodo, a.nombre_asignatura,
              ROUND((c.nota1 + c.nota2 + c.nota3) / 3) AS promedio
              FROM calificacion c 
              INNER JOIN estudiante e ON c.id_estudiante = e.id_estudiante
              INNER JOIN curso g ON c.id_curso = g.id_curso
              INNER JOIN asignatura a ON c.id_asignatura = a.id_asignatura 
              INNER JOIN profesor p ON c.id_profesor = p.id_profesor
              INNER JOIN periodo pd ON c.id_periodo = pd.id_periodo
              WHERE c.id_estudiante = '$id_s'";
    
    $result = mysqli_query($conexion, $query);


    while($datos = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $datos['nombre_periodo'] . "</td>";
        echo "<td>" . $datos['nombre_asignatura'] . "</td>";
        echo "<td>" . $datos['nota1'] . "</td>";
        echo "<td>" . $datos['nota2'] . "</td>";
        echo "<td>" . $datos['nota3'] . "</td>";
        echo "<td>" . $datos['promedio'] . "</td>";

        echo "<td>";
        if($datos['promedio'] < 7 ) { 
            echo "<font color='red'>❌ Reprobado</font>"; 
        } else {
            echo "<font color='green'>✅ Aprobado</font>";
        } 
        echo "</td>";
        // Enlace para editar las notas
        echo "<td><a class='editar' href='editar_nota.php?id_calificacion=" . $datos['id_calificacion'] . "'>✏️ Editar</a></td>";
        echo "</tr>";
    }
}

?>
</table>
</center>
</body>
</html>

