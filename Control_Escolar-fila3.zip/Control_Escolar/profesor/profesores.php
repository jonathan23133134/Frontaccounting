<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Administrar Profesores</title>
<style>
/* Estilos generales */
* {
    margin: 0;
    font-family: 'ubuntu';
}

body{
    background-image: url('img/fondo.png');
    background-size: cover;

}
table {
    background-color: white;
    width: 85%;
    border-collapse: collapse;
    margin-top: 1%;
    font-size: 18px;
    box-shadow: 2px 3px 15px grey;
}

.nav{
   width:100%;
   height:15px;
   background-color: #1c2833 ;
   color:white;
   margin:0%;
   box-shadow:2px 3px 15px grey;
  }
  
td a{
 text-decoration:none;
 font-size:55px;
}

tr {
    text-align: center;
}

th,
td {
    padding: 20px;
}

th {
    background-color: #246355;
    color: white;
}

tr:nth-child(even) {
    background-color: #ddd;
}


.resumen {
    background-color: #4CAF50; 
    color: white; 
    padding: 8px 15px; 
    font-size: 15px;
    text-decoration: none; 
    border-radius: 5px; 
    cursor: pointer; 
}

.resumen:hover {
    background-color: #45a049; 
}
.nav tr td img{
margin-left:0%;
padding:3px 3px;
}
.titu{
margin-right:20%;
font-size:40px;
}
.tito{
width:60%;
}
</style>
</head>
<body>
	<?php
	session_start();
	$usuario=$_SESSION['usuario'];
	if(!isset($usuario)){
	header("location: ../login.php");
	}
	?>
<table class="nav"> 
<tr>
<td><img src="img/logo.png" width="25%"></td>
<td class="tito"> <h1 class="titu">Registro de Profesores<br></td>
<td></td>

<td><a href="administrar.php">⬅️</a></td>
<td></td>
</tr>
</table>
   

<center>
<table>
           
<tr>
<th>Id</th>
<th>Nombre</th>
<th>Apellido</th>
<th>Sexo</th>
<th>Id Curso</th>
<th>Id Asignatura</th>
<th>Resumen Alumnos</th> 
</tr>
           
            <?php 
            include 'conexion.php';
            $sql = "SELECT * FROM profesor";
            $resultado = mysqli_query($conexion, $sql);

            if (mysqli_num_rows($resultado) > 0) {
            while ($profes = mysqli_fetch_assoc($resultado)) {
            echo "<tr>";
            echo "<td>" . $profes['id_profesor'] . "</td>";
            echo "<td>" . $profes['nombre_profesor'] . "</td>";
            echo "<td>" . $profes['apellidos_profesor'] . "</td>";
            echo "<td>" . $profes['sexo'] . "</td>";
            echo "<td>" . $profes['id_curso'] . "</td>";
            echo "<td>" . $profes['id_asignatura'] . "</td>";
            echo "<td><a href='resumen.php?id_profesor=" . $profes['id_profesor'] . "' class='resumen'>Ver Resumen</a></td>";
            echo "</tr>";
             }
            } 
            mysqli_close($conexion);
            ?>

</table>
</center>
</body>
</html>

