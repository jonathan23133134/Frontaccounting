<html>
<head>
<meta charset="UTF-8">
<title>Administrar Asignaturas</title>
</head>
  <style>
  *{
   margin:0;
   font-family:'ubuntu';
  }
  
  body{
   background-image: url('img/fondo.png');
   background-size: cover;
  } 
  
  table{
   background-color:white;
   text-align:center;
   width:70%;
   border-collapse:collapse;
   font-size:17px;
   box-shadow:2px 3px 15px grey;
  }
  
  th ,td {
   padding:20px;
  }
  
  th{
   background-color:#246355;
   color:white;
   font-size:18px;
  }
    
  .nav{
   width:100%;
   height:20px;
   background-color: #1c2833 ;
   color:white;
   margin:0%;
   box-shadow:2px 3px 15px grey;

  }

  td a{
   text-decoration:none;
   font-size:55px;
  }

  .titu{
   margin-right:15%;
   font-size:40px;
  }
  
  .tito{
   width:60%;
  }
  </style>

<body>

	<?php
	session_start();
	$usuario=$_SESSION['usuario'];
	if(!isset($usuario)){
	header("location: ../login.php");
	}
	?>
 
<table class="nav"> 
<tr>
<td><img src="img/logo.png" width="25%"></td>
<td class="tito"> <h1 class="titu">Registro de Asignaturas<br></td>
<td></td>
<td><a href="administrar.php">⬅️</a></td>
<td></td>
</tr>
</table>

<center>
 
<table>
<br>
<tr>
 <th>Id</th>
 <th>Nombre</th>
</tr>

	<?php
	include 'conexion.php';

	$materia = "SELECT * FROM profesor_responsabilidad pr INNER JOIN profesor p ON pr.id_profesor = p.id_profesor INNER JOIN asignatura a ON 
	pr.id_asignatura = a.id_asignatura INNER JOIN curso c ON pr.id_curso = c.id_curso INNER JOIN usuario_profesor up ON up.id_profesor = 		p.id_profesor WHERE up.usuario = '$usuario'";
 
	$resul = mysqli_query($conexion, $materia);
	if (mysqli_num_rows($resul) > 0) {
	while ($asig = mysqli_fetch_assoc($resul)) {
	echo "<tr>";
	echo "<td>" . $asig['nombre_curso'] . "</td>";
	echo "<td>" . $asig['nombre_asignatura'] . "</td>";
	echo "</tr>";
	}
	}
	mysqli_close($conexion);
	?>

</table>
</center>
</body>
</html>
