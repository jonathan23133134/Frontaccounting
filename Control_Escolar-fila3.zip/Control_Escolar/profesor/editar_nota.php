<?php
session_start();
$usuario = $_SESSION['usuario'];
if (!isset($usuario)) {
    header("location: ../login.php");
    exit(); 
}

include 'conexion.php'; 

if(isset($_GET['id_calificacion'])) {
    $id_calificacion = $_GET['id_calificacion'];
    
    $cali = "SELECT * FROM calificacion WHERE id_calificacion = '$id_calificacion'";
    $resultado = mysqli_query($conexion, $cali);
    $calificacion = mysqli_fetch_assoc($resultado);
    

    if (isset($_POST['Guardar'])) {
        $nota1 = $_POST['nota1'];
        $nota2 = $_POST['nota2'];
        $nota3 = $_POST['nota3'];
        $promedio = ($nota1 + $nota2 + $nota3)/3;
        
        $contra = "UPDATE calificacion SET nota1 = '$nota1', nota2 = '$nota2', nota3 = '$nota3', promedio = '$promedio' WHERE id_calificacion = '$id_calificacion'";
        $contra = mysqli_query($conexion, $contra);
        
        if ($contra) {
            header("location: registro_calificaciones.php");
            exit();
        } else {
            echo "Error al actualizar las notas: " . mysqli_error($conexion);
        }
    }
} else {
    header("location: registro_calificaciones.php");
    exit();
}
?>

<html>
<head>
<meta charset="UTF-8">
<title>Editar Notas de Estudiante</title>
<style>
    body {
        background-image: url('img/fonfo2.gif');
        background-size: cover;
    }
    form {
        width: 30%;
        height: 80%;
        background-color: #1c2833;
        box-shadow: 5px 7px 10px purple;
        border-radius: 3%;
        margin: 0 auto;
        padding: 1%;
        margin-top: 4%;
    }
    label {
        display: block;
        margin-bottom: 5px;
        color: white;
        margin-left: 15%;
    }
    input[type="number"] {
        width: 70%;
        padding: 6px;
        margin-bottom: 10px;
        border: 1px solid white;
        border-radius: 4px;
        margin-left: 15%;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        float: right;
    }
    h1 {
        text-align: center;
        color: white;
        font-size: 25px;
    }
    img {
        position: absolute;
        top: 40px;
        left: 50px;
        width: 220px;
        filter: drop-shadow(0 10px 8px purple);
    }
</style>
</head>
<body>

<img src="img/logo.png">
<form action="" method="post">
    <h1>Editar Notas de Estudiante</h1>


    <input type="hidden" name="id_calificacion" value="<?php echo $calificacion['id_calificacion']; ?>">


    <label for="nota1">Nota 1:</label>
    <input type="number" id="nota1" name="nota1" autocomplete="off" value="<?php echo $calificacion['nota1']; ?>" required min="0" max="10">

    <label for="nota2">Nota 2:</label>
    <input type="number" id="nota2" name="nota2" autocomplete="off" value="<?php echo $calificacion['nota2']; ?>" required min="0" max="10">

    <label for="nota3">Nota 3:</label>
    <input type="number" id="nota3" name="nota3" autocomplete="off" value="<?php echo $calificacion['nota3']; ?>" required min="0" max="10">

    <input type="submit" value="Guardar" name="Guardar">
</form>
</body>
</html>

