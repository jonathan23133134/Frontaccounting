	<?php 
	include 'conexion.php';
	session_start();
	$usuario = $_SESSION['usuario'];
		if (!isset($usuario)) {
	header("location: ../login.php");
	exit(); 
	}

	// Consulta para obtener el nombre del profesor desde la base de datos
	$profea_estu = "SELECT profesor.nombre_profesor, usuario_profesor.id_profesor
	FROM usuario_profesor 
	INNER JOIN profesor ON usuario_profesor.id_profesor = profesor.id_profesor 
	WHERE usuario_profesor.usuario = '$usuario'";
	$result_profe = mysqli_query($conexion, $profea_estu);
	
	$profe = mysqli_fetch_assoc($result_profe);
	$nombre_profesor = $profe['nombre_profesor'];
	$id_profesor = $profe['id_profesor'];
	?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Estudiantes</title>
   <style>
   body {
    font-family: ubuntu;
    background-image: url('img/fondo.png');
    background-size: cover;
   }
        
   .datos1 {
    width: 90%;
    margin: 0 auto;
    border-collapse: collapse;
    background-color: white;
    text-align: center;
   }
   .datos {
    width: 90%;
    margin: 0 auto;
    border-collapse: collapse;
    background-color: white;
    text-align: center;
   }
        
   th, td {
    padding: 1%;
    border: 0.5px solid grey;
   }
        
   h2 {
    margin-right: 10%;
    font-size: 30px;
    color: white;
   }
        
   .codi {
    background-color: #1c2833;
   }
       
   .logo {
    background-color: #1c2833;
    width: 120px;
   }
        
   .nav {
    float: right;
    margin-top: 2%;
    width: 50%;
    position: absolute;
    align-items: center;
    justify-content: center;
   }
        
   .nav a {
    color: white;
    padding: 22px;
    text-decoration: none;
    font-size: 110%;
    background-color: #34495e;
    border-radius: 5%;
    margin-left: 3%;
   }
        
   .nav a:hover {
    background-color: #5d6d7e;
   }
   /*Enlaces de acción*/
.editar{
 width:100%;
 border: none;
 color:white;
 padding:5px;
 text-decoration:none;
 cursor:pointer;
 background:#e74c3c;
 border-radius:10%;
}
   </style>

</head>
<body>


<div class="nav">
<nav>
    <a href="administrar.php">Regresar</a>
    <a href="guardar_estudiante.php" class="boton-agregar">Agregar Estudiante</a>
</nav>
</div>
<br><br><br><br>
<table class="datos1">
<th class="logo">
    <img src="img/logo.png" width="75px">
    </a>
</th>
<th class="codi">
    <h2 align="center">Estudiantes</h2>
</th>
</tr>
<tr>
<th>Profesor:</th>
<td><?php echo $nombre_profesor; ?></td>
</tr>
</table>

<form action="#" method="post">
<table class="datos1">
<tr>
<th>Curso:</th>
<td>

	<?php
	$curso_query = "SELECT DISTINCT curso.nombre_curso 
	FROM curso 
		INNER JOIN profesor ON curso.id_curso = profesor.id_curso
	WHERE profesor.id_profesor = '$id_profesor'";
	$result_curso = mysqli_query($conexion, $curso_query);

	if(mysqli_num_rows($result_curso) > 0) {
		echo "<select name='curso'>";
	while ($grado = mysqli_fetch_assoc($result_curso)) {
	echo "<option value='" . $grado['nombre_curso'] . "'>" . $grado['nombre_curso'] . "</option>";
	}
	echo "</select>";
	}
	?>


</td>
</tr>
</table>

<table class="datos">
<tr>
<th>NIE</th>
<th>Nombre</th>
<th>Apellido</th>
<th>Sexo</th>
<th>Edad</th>
<th colspan="2">Acción</th>
</tr>

	<?php
	$estu = "SELECT id_estudiante, estudiante.NIE, estudiante.nombre, estudiante.apellidos, estudiante.sexo, estudiante.edad
	FROM estudiante
	INNER JOIN curso ON estudiante.id_curso = curso.id_curso
		INNER JOIN profesor ON curso.id_curso = profesor.id_curso
	WHERE profesor.id_profesor = '$id_profesor'";
	$result_estu = mysqli_query($conexion, $estu);

	if(mysqli_num_rows($result_estu) > 0) {
	while ($estudiante = mysqli_fetch_assoc($result_estu)) { ?>
	<tr>
	<td><?php echo $estudiante['NIE']; ?> </td>
	<td><?php echo $estudiante['nombre']; ?> </td>
	<td><?php echo $estudiante['apellidos']; ?> </td>
	<td><?php echo $estudiante['sexo']; ?> </td>
	<td><?php echo $estudiante['edad']; ?> </td>
     <td><a class="editar" href="editar_estudiante.php?id_estudiante=<?php echo $estudiante['id_estudiante']; ?>">✏️ Editar</a></td>
     <td><a class="editar" href="estudiante.php?id_estudiante=<?php echo $estudiante['id_estudiante']; ?>">⛔️ Eliminar</a></td>
       </tr>
<?php

	}
	}
	mysqli_close($conexion);
	?>
	
<?php
if($_GET['id_estudiante']){
 $id_estudiante=$_GET['id_estudiante'];
 if(isset($id_estudiante)){
 echo "<script>alert('¿Realmente desea eliminar el registro?');</script>";
 include '../conexion.php';
 $result=mysqli_query($conexion, "DELETE FROM estudiante WHERE estudiante.id_estudiante = '$id_estudiante'");
}}
?>

</table>
</form>
</body>
</html>

