
<html>
<head>
<meta charset="UTF-8">
<title>Formulario de Registro de Estudiante</title>
<style>
        body {
            background-image: url('img/fonfo2.gif');
            background-size: cover;
        }
        form {
            width: 30%;
            height: 80%;
            background-color: #1c2833;
            box-shadow: 5px 7px 10px purple;
            border-radius: 3%;
            margin: 0 auto;
            padding: 1%;
            margin-top: 4%;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: white;
            margin-left: 15%;
        }
        input[type="text"], input[type="number"], select {
            width: 70%;
            padding: 6px;
            margin-bottom: 10px;
            border: 1px solid white;
            border-radius: 4px;
            margin-left: 15%;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }
        h1 {
            text-align: center;
            color: white;
            font-size: 25px;
        }
        img {
            position: absolute;
            top: 40px;
            left: 50px;
            width: 220px;
            filter: drop-shadow(0 10px 8px purple);
        }
    </style>
</head>
<body>

	<?php
	session_start();
	$usuario = $_SESSION['usuario'];
	if (!isset($usuario)) {
	header("location: ../login.php");
	}
	?>

<img src="img/logo.png">
<form action="" method="post">
<h1>Matricular Estudiante</h1>

<label for="NIE">Nie:</label>
<input type="text" id="NIE" name="NIE" autocomplete="off" required>

<label for="nombre">Nombre:</label>
<input type="text" id="nombre" name="nombre" autocomplete="off" required>

<label for="apellidos">Apellidos:</label>
<input type="text" id="apellidos" name="apellidos" autocomplete="off" required>

<label for="sexo">Sexo:</label>
<select id="sexo" name="sexo" autocomplete="off" required>
<option value="M">Masculino</option>
<option value="F">Femenino</option>
</select>

<label for="edad">Edad:</label>
<input type="number" id="edad" name="edad" autocomplete="off" required min="1" max="21">

<label for="curso">Curso:</label>
<select name="curso">
   
	<?php include 'conexion.php';

	$sql_cursos_profesor = "SELECT curso.id_curso, curso.nombre_curso 
	FROM curso 
	INNER JOIN profesor ON curso.id_curso = profesor.id_curso 
	INNER JOIN usuario_profesor ON profesor.id_profesor = usuario_profesor.id_profesor 
	WHERE usuario_profesor.usuario = '$usuario'";
	$result_cursos_profesor = mysqli_query($conexion, $sql_cursos_profesor);
		
	while ($fila_curso = mysqli_fetch_assoc($result_cursos_profesor)) {
	echo "<option value='" . $fila_curso['id_curso'] . "'>" . $fila_curso['nombre_curso'] . "</option>";
	}
	?>

</select>
<input type="submit" value="Guardar" name="Guardar">
</form>

	<?php 
	include 'conexion.php';
	
	if (isset($_POST['Guardar'])) {

	$NIE = $_POST['NIE'];
	$nombre = $_POST['nombre'];
	$apellidos = $_POST['apellidos'];
	$sexo = $_POST['sexo'];
	$edad = $_POST['edad'];
	$curso = $_POST['curso'];
	

	$sql = "INSERT INTO estudiante (NIE, nombre, apellidos, sexo, edad, id_curso) 
	VALUES ('$NIE', '$nombre', '$apellidos', '$sexo', '$edad', '$curso')";

	$result = mysqli_query($conexion, $sql);

	if ($result) {
	// Generar usuario haciendo uso de su NIE y la contraseña aleatoria
	$usuario = $NIE . "@edu.sv";
	$contraseña = rand(100000, 999999);

	// Insertar credenciales (usuario y contraseña) a la tabla usuario_estudiante
	$sql = "INSERT INTO usuario_estudiante (id_estudiante, usuario, contraseña) 
	VALUES (LAST_INSERT_ID(), '$usuario', '$contraseña')";
	$result = mysqli_query($conexion, $sql);

	// Si la consulta fue exitosa, redirigir a la página estudiante.php
	if ($result) {
	header("location: estudiante.php");
	  }
	 }
	}
	?>


</body>
</html>

