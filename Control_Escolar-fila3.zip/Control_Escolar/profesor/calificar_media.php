	<?php
	session_start();
	$usuario = $_SESSION['usuario'];
	if (!isset($usuario)) {
	header("location: ../login.php");
	exit();
	}

	include 'conexion.php'; 

	// Obtener el ID del profesor en sesión
	$sql_id_profesor = "SELECT id_profesor FROM usuario_profesor WHERE usuario = '$usuario'";
	$resultado_id_profesor = mysqli_query($conexion, $sql_id_profesor);

	$fila_id_profesor = mysqli_fetch_assoc($resultado_id_profesor);
	$id_profesor = $fila_id_profesor['id_profesor'];
	?>

<html>
<head>
<meta charset="UTF-8">
<title>Registrar Calificación de Media</title>
    
   <style>
   body {
   margin:0;
   padding:0;
    font-family: 'ubuntu';
    background-image: url('img/fondo.png');
    background-size: cover;
   }
   .nav{
    width:100%;
    height:20px;
    background-color: #1c2833 ;
    color:white;
    box-shadow:2px 3px 15px grey;
   }

   .nav td {
    border: 0;
   }
 
   .nav td a{
    text-decoration:none;
    font-size:55px;   
   }

  .titu{
   margin-left:-10%;
   font-size:40px;
  }
  
  .datos {
   width: 70%;
      font-size:15px;
   margin: 1 auto;
      margin-top: 1%;
   border-collapse: collapse;
   background-color: #eaeded;
   box-shadow: 2px 6px 15px grey;
  }

  th, td {
   padding: 8px;
   border: 1px solid black;
   text-align: left;
   }


   input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    padding: 8px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
   }
   
   select,input[type="number"]{
    height:30px;
   }
   </style>

</head>
<body>
<table class="nav"> 
<tr>
<td><img src="img/logo.png" width="25%"></td>
<td> <h1 class="titu">Registro de Asignaturas<br></td>
<td></td>
<td><a href="registro_calificaciones.php">⬅️</a></td>
<td></td>
</tr>
</table>

<form action="#" method="post">
<table class="datos">
 <tr>
 <th colspan="3" id="cabecera">
<label>Profesor:&nbsp;&nbsp;</label>
  <select name="profesor">
                       
	<?php
	$sql_profesores = "SELECT * FROM profesor 
	INNER JOIN usuario_profesor ON profesor.id_profesor = usuario_profesor.id_profesor 
	WHERE usuario = '$usuario'";
	$resultado_profesores = mysqli_query($conexion, $sql_profesores);
	while ($fila = mysqli_fetch_assoc($resultado_profesores)) {
	echo "<option value='" . $fila['id_profesor'] . "'>" . $fila['nombre_profesor'] . "</option>";
	}
	?>

      
</select>
 </th>
</tr>
<tr>
 <td colspan="8" id="cabecera" >
<label>Seleccionar Curso:&nbsp;&nbsp;</label>
<form action="#" method="post">
<select name="buscar" required>
      
	<?php
	// Consulta para obtener los cursos del profesor
	//##Camibio
        $sql_curso = "SELECT * FROM profesor_responsabilidad pr INNER JOIN profesor p ON pr.id_profesor = p.id_profesor INNER JOIN asignatura a 
        ON pr.id_asignatura = a.id_asignatura INNER JOIN curso c ON pr.id_curso = c.id_curso INNER JOIN usuario_profesor up ON up.id_profesor = 
        p.id_profesor WHERE up.usuario = '$usuario'";

	$resultado_curso = mysqli_query($conexion, $sql_curso);
	
	// Si no hay ningún error, el bucle while procesará los resultados
	while ($fila_curso = mysqli_fetch_assoc($resultado_curso)) {
	echo "<option value='" . $fila_curso['id_curso'] . "'>" . $fila_curso['nombre_curso'] . "</option>";
	}
	?>


</select> &nbsp;&nbsp;&nbsp;<input type="submit" value="Buscar">
</form>
 </td>

</tr>

<tr>
 <th width="33.3%">Estudiante</th>
 <th width="33.3%">Asignatura</th>
 <th width="33.3%">Periodo</th>
</tr>

 <tr>
  <td>
  <?php
	if (isset($_POST['buscar'])) {
	$termino = $_POST['buscar'];
	} 
	?>

<select name="studiante">
                       
	<?php
	$result = mysqli_query($conexion, "SELECT * FROM estudiante WHERE id_curso = '$termino'");
	while ($estudiante = mysqli_fetch_array($result)) { 
	echo "<option value='" . $estudiante['id_estudiante'] . "'>" . $estudiante['nombre'] ."</option>";
	 } 
	 ?>
                    
</select></td>
  <td>
  <select name="asignatura">
                       
	<?php

       $sql_asignaturas = "SELECT * FROM profesor_responsabilidad pr INNER JOIN profesor p ON pr.id_profesor = p.id_profesor INNER JOIN 
       asignatura a ON pr.id_asignatura = a.id_asignatura INNER JOIN curso c ON pr.id_curso = c.id_curso INNER JOIN usuario_profesor up ON 
       up.id_profesor = p.id_profesor WHERE up.usuario = '$usuario' AND pr.id_curso = '$termino'";

	$resultado_asignaturas = mysqli_query($conexion, $sql_asignaturas);
	while ($fila = mysqli_fetch_assoc($resultado_asignaturas)) {
	echo "<option value='" . $fila['id_asignatura'] . "'>" . $fila['nombre_asignatura'] . "</option>";
	}
	?>

</select></td>
  <td>
  <select name="periodo">
                      
	<?php
	$sql_periodos = "SELECT * FROM periodo";
	$resultado_periodos = mysqli_query($conexion, $sql_periodos);
	while ($fila = mysqli_fetch_assoc($resultado_periodos)) {
	echo "<option value='" . $fila['id_periodo'] . "'>" . $fila['nombre_periodo'] . "</option>";
	}
	?>

</select></td>
 </tr>


<tr>
 <th>Nota 1</th>
 <th>Nota 2</th>
 <th>Nota 3</th>
</tr>

  <tr>
   <td><input type="number" name="nota1" min="1" max="10"></td>
   <td><input type="number" name="nota2" min="1" max="10"></td>
   <td><input type="number" name="nota3" min="1" max="10"></td>
 </tr>

<tr>
<td colspan="3"><input type="submit" name="calificar" value="Calificar"></td>
 </tr>
 
</table>
</form>

	<?php
	if (isset($_POST['calificar'])) {
        // vamos a obtener los datos del formulario
        $id_estudiante = $_POST['studiante'];
        $id_curso = $_POST['buscar'];
        $id_asignatura = $_POST['asignatura'];
        $id_profesor = $_POST['profesor'];
        $id_periodo = $_POST['periodo'];
        $nota1= $_POST['nota1'];
        $nota2= $_POST['nota2'];
        $nota3= $_POST['nota3'];
        $promedio=($nota1+$nota2+$nota3)/3;
        
        $result_verificar=mysqli_query($conexion, "SELECT * FROM calificacion WHERE id_estudiante = '$id_estudiante' AND id_periodo = 
        '$id_periodo' AND id_asignatura = '$id_asignatura'");
        
        if(mysqli_num_rows($result_verificar) > 0){
        echo "<script>alert('Esta califcación ya esta registrada.');</script>";
        } else {

        $sql = "INSERT INTO calificacion (id_estudiante, id_curso, id_asignatura, id_profesor, id_periodo, nota1, nota2, nota3, promedio) 
        VALUES ('$id_estudiante', '$id_curso', '$id_asignatura', '$id_profesor', '$id_periodo', '$nota1', '$nota2', '$nota3', '$promedio')";
	}
        $result = mysqli_query($conexion, $sql);
        if($result == true){
        header("location:registro_calificaciones.php");
        }
	}
	mysqli_close($conexion);
	?>


</body>
</html>

