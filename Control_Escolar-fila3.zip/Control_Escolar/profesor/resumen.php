<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Resumen</title>
<style>
body {
    margin: 0;
    padding: 0;
    font-family: 'ubuntu';
    background-image: url('img/fondo.png');
    background-size: cover;
}

.nav {
    width: 100%;
    height: 20px;
    background-color: #1c2833;
    color: white;
    box-shadow: 2px 3px 15px grey;
}

.nav td {
    border: 0;
}

.nav td a {
    font-size: 55px;
}

.titu {
    margin-left: -10%;
    font-size: 40px;
}

.datos {
    width: 70%;
    font-size: 15px;
    margin: 0 auto; 
    margin-top: 1%;
    border-collapse: collapse;
    background-color: #eaeded;
    box-shadow: 2px 6px 15px grey;
}

th,
td {
    padding: 8px;
    border: 1px solid black;

}

input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    padding: 8px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

select,
input[type="number"] {
    height: 30px;
}
</style>
</head>
<body>
<table class="nav">
<tr>
<td><img src="img/logo.png" width="25%"></td>
<td>
<h1 class="titu">Lista de estudiantes</h1>
</td>
<td><a href="administrar.php">⬅️</a></td>
<td></td>
</tr>
</table>

	<?php
	session_start();
	$usuario = $_SESSION['usuario'];
	if (!isset($usuario)) {
	header("location: ../login.php");
	}
	?>

<form action="#" method="post">
<table class="datos">

<tr>
<th>Profesor:</th>
<td>
<select name="profesor">

	<?php include 'conexion.php';


	$sql_profesores = "SELECT * FROM profesor";
	$resultado_profesores = mysqli_query($conexion, $sql_profesores);


	while ($fila = mysqli_fetch_assoc($resultado_profesores)) {
	echo "<option value='" . $fila['id_profesor'] . "'>" . $fila['nombre_profesor'] . "</option>";
	}
	?>

</select>
</td>
<th>Asignatura:</th>
<td>
<select name="asignatura">

	<?php
	$sql_asignaturas = "SELECT * FROM asignatura";
	$resultado_asignaturas = mysqli_query($conexion, $sql_asignaturas);

	while ($fila = mysqli_fetch_assoc($resultado_asignaturas)) {
	echo "<option value='" . $fila['id_asignatura'] . "'>" . $fila['nombre_asignatura'] . "</option>";
	}
	?>


</select>
</td>
</tr>
<tr>
<td colspan="6" align="right">
<input type="submit" name="buscar" value="buscar">
</td>
</tr>
</table>
</form>

	<?php
	if (isset($_POST['buscar'])) {

    	$id_profesor = $_POST['profesor'];
    	$id_asignatura = $_POST['asignatura'];

    	include 'conexion.php';

    	$sql_estudiantes = "SELECT estudiante.nombre AS nombre_estudiante, calificacion.promedio 
	FROM calificacion 
	INNER JOIN estudiante ON calificacion.id_estudiante = estudiante.id_estudiante 
	WHERE calificacion.id_profesor = '$id_profesor' 
	AND calificacion.id_asignatura = '$id_asignatura'";

    	$resultado_estudiantes = mysqli_query($conexion, $sql_estudiantes);

    	if (mysqli_num_rows($resultado_estudiantes) > 0) {
        echo "<table class='datos'>";
        echo "<tr><th>Estudiante</th><th>Promedio</th></tr>";
        while ($fila = mysqli_fetch_assoc($resultado_estudiantes)) {
        echo "<tr>";
        echo "<td>" . $fila['nombre_estudiante'] . "</td>";
        echo "<td>" . $fila['promedio'] . "</td>";
        echo "</tr>";
        }
        echo "</table>";
        echo "</div>";
    	}
	mysqli_close($conexion);
	}
	?>
</body>
</html>

