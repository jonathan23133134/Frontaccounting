
<html>
<head>
<meta charset="utf-8">
<title>Editar Contraseña Profesor</title>
   <style>
   body {
    font-family:ubuntu;
    color: white;
    background-image: url('img/fondoedit.avif');
    background-size: cover;
   }

   .form {
    width: 30%;
    height: 80%;
    background-color: #1c2833;
    box-shadow: 5px 7px 10px purple;
    border-radius: 3%;
    margin: 0 auto;
    padding: 2%;
  }

  p {
   font-size: 100%;
   margin-left: 20%;
  }

  input[type=text], input[type=password] {
   width: 60%;
   height: 5%;
   margin-left: 20%;
   color: black;
   font-size: 100%;
   margin-bottom: 1em; 
  }

  input[type=submit] {
   width: 30%;
   height: 5%;
   color: black;
   font-size: 100%;
   background-color: #28b463;
   cursor: pointer;
   margin-left: 35%;
  }
        
  .nav{
   position: absolute;
   top: 40px; 
   left: 50px;
   width: 180px;
  }
 
  .nav a{
   color: black;
   padding:20px;
   text-decoration:none;
   font-size:110%;
   background-color: #58d68d ;
   border-radius:5%;
  } 
  </style>

</head>
<body>

	<?php
	session_start();
	$usuario=$_SESSION['usuario'];
	if(!isset($usuario)){
	header("location: ../login.php");
	}
	?>

<div class="nav">
<a href="administrar.php">Regresar</a>
</div>
<br>
<div class="contenedor">
<div class="form">

<form action="#" method="post">
<center><h1>Datos Personales</h1>
<img src="img/logo.png" width="35%">
</center>

<p>Usuario: </p>    
<input type="text" name="usuario" autocomplete="off" required><br>
  
<p>Contraseña Anterior: </p> 
<input type="password" name="contraseña_anterior" autocomplete="off" required>
          
<p>Nueva Contraseña: </p> 
<input type="password" name="contraseña_nueva" autocomplete="off" required>
           
<input type="submit" name="actualizar" value="Actualizar"><br>
</form>
</div>
</div>

	<?php include 'conexion.php';
	
	$usuario = $_POST['usuario'] ?? '';
	$contraseña_anterior = $_POST["contraseña_anterior"] ?? '';
	$contraseña_nueva = $_POST["contraseña_nueva"] ?? '';
	$sql_actualizar = "UPDATE usuario_profesor SET contraseña='$contraseña_nueva' WHERE usuario='$usuario' AND 		
	contraseña='$contraseña_anterior'";
	$resultado = mysqli_query($conexion, $sql_actualizar);
	mysqli_close($conexion);
	?>

</body>
</html>


