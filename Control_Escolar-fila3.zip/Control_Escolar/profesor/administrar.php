<html>
<head>
<meta charset="UTF-8">
<title>Administrar</title>
</head>
<body>

	<?php
	session_start();
	$usuario=$_SESSION['usuario'];
	if(!isset($usuario)){
	header("location: ../login.php");
	}
	?>

<div class="nav">
 <nav>
  <a href="cerrar.php">🔒 Cerrar Sesión</a>
 </nav>
</div>


<label for="menu-lateral" class="icono">☰</label>
<input type="checkbox" id="menu-lateral">


<div class="menu">
<div class="menu-lateral">

<table>
<tr><th>Administrar🛠️</th></tr>
<tr><td><a href="profesores.php">👨‍🏫 Profesores</a></td></tr>
<tr><td><a href="asignaturas.php">📚 Asignaturas</a></td></tr>
<tr><td><a href="registro_calificaciones.php">✍️ Calificaciones</a></td></tr>
<tr><td><a href="estudiante.php">👨‍🎓 Alumnos</a></td></tr>
<tr><td><a href="editar_usuario.php">🙎‍♂️ Usuario</a></td></tr>
</table>

<label for="menu-lateral" class="icono">X</label>

</div>
</div>

<center>

<section>
<center><div id="titulo"><h1>Administración Escolar</h1></div>
<br>
<br>
<img src="img/logo.png" width="27%" id="img">
</center>
<div class="datos">
<br>
<div id="datos2"><img src="img/0.png" width="30%"><br><br></div> 
<div id="datos3"><img src="img/kathy.1.jpg" width="30%"><br><br></div>
<div id="datos4"><img src="img/12356.gif" width="30%"><br><br></div>
</section>

</center>
</body>
</html>
 <style>
 *{   
  margin:0;
  font-family:ubuntu;
 }
 
 body{
  background-color:black;
 }
 
 /*Barra Navegadora*/
 .nav{
  float:right;
  width:25%;
  height:11%;
  display:flex;
  align-items:center;
 }
 
 .nav a{
  color: white;
  padding:15px;
  margin-left:170px;
  text-decoration:none;
  font-size:100%;
  background-color:#34495e;
  border-radius:6%;
 }
 
 .nav a:hover{
  background-color: #5d6d7e ;
 }
 
 /*Menú lateral*/
 .icono{
  font-size:350%;
  margin: 1% 5%;
  cursor:pointer;
  color: white;
 }
 
 #menu-lateral{
  display:none;
 }
 
 .menu{
  position:absolute;
  background:rgba(0,0,0,0.5);
  width:100%;
  height:100vh;
  top:0; 
  transition:all 500ms ease;
  opacity:0;
  visibility:hidden;
 }
 
 #menu-lateral:checked ~ .menu{
  opacity:2;
  visibility:visible;
 }
 
 .menu-lateral{
  width:17%;
  height:100vh;
  max-width:250px;
  background-color:#1c1c1c;
  position:relative;
  transition: all 550ms ease;
  transform:translateX(-100%);
 }
 
 #menu-lateral:checked ~ .menu .menu-lateral{
  transform:translateX(0%);
 }
 
 .menu-lateral label{
  position:absolute;
  top:15px;
  right:5px;
  color:white;
  cursor:pointer;
  font-size:18px;
  font-weight:bold;
 }
 
 table{
  width:100%;
  height:100%;
  text-align: left;
  font-size:120%;
 }
 
 th{
  background-color: #369681;
  text-align: center;
 }
 
 table tr td a{
 text-decoration:none;
 color:white;
 margin-left: 15%;
 }
 
 td:hover{
  background-color:blue;
 }

 section{
  margin-top:-10%;
  width:80%;
  height:85%;
  overflow:hidden;
  text-align:center;
 }
 
 #titulo{
  width:70%;
  font-size:200%;
  color:white;
  margin-top:
 
 }
 .datos{
  width:90%;
  margin-left:6%;
 }

 #img{
  filter: drop-shadow(12px 13px 25px purple);
 }

 #datos2{
  width:28%;
  height:30%;
  float:left;
  margin:2% 2.5%;
  display:flex;
  align-items:center;
  color:white;
  font-size:100%;
  font-weight:bold;
 }
  
 #datos2 img{
  width: 100%;
  height:100%; 
  box-shadow:4px 6px 8px purple;
 }
 
 #datos3 img{
  width: 100%;
  height:100%;
 }
 
 #datos4 img{
  width: 100%;
  height:100%;
 }
 
 #datos3{
  width:26%;
  height:30%;
  float:left;
  margin:2% 2.5%;
 }

 #datos4{
  width:28%;
  height:30%;
  float:left;
  margin:2% 2.5%;
  background-color: #f39c12 ;
  display:flex;
  align-items:center;
  color:white;
  font-size:100%;
  font-weight:bold;
 }

 #datos1, #datos3, #datos4{
  box-shadow:4px 6px 8px purple;
}
</style>
