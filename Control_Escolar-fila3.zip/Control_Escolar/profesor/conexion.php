	<?php
	 $conexion=mysqli_connect('localhost','jose','jose200516','prueba_escuela');
	 
	 error_reporting(0);
	?>

